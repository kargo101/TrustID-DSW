﻿namespace ProfileManagement
{
    partial class frmSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpSettings = new System.Windows.Forms.GroupBox();
            this.lblSettingsDescription = new System.Windows.Forms.Label();
            this.grpAccInfo = new System.Windows.Forms.GroupBox();
            this.btnSaveChanges = new System.Windows.Forms.Button();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.grpChangePass = new System.Windows.Forms.GroupBox();
            this.lblConfirmNewPass = new System.Windows.Forms.Label();
            this.lblNewPass = new System.Windows.Forms.Label();
            this.lblCurrentPass = new System.Windows.Forms.Label();
            this.btnUpdatePass = new System.Windows.Forms.Button();
            this.txtConfirmNewPass = new System.Windows.Forms.TextBox();
            this.txtNewPass = new System.Windows.Forms.TextBox();
            this.txtCurrentPass = new System.Windows.Forms.TextBox();
            this.grpNotificationsPref = new System.Windows.Forms.GroupBox();
            this.lblTransAlertInfo = new System.Windows.Forms.Label();
            this.lblPushInfo = new System.Windows.Forms.Label();
            this.lblEmailInfo = new System.Windows.Forms.Label();
            this.chkTransAlerts = new System.Windows.Forms.CheckBox();
            this.chkPushNotis = new System.Windows.Forms.CheckBox();
            this.chkEmailNotis = new System.Windows.Forms.CheckBox();
            this.grpProfileVisbility = new System.Windows.Forms.GroupBox();
            this.lblProfileRepInfo = new System.Windows.Forms.Label();
            this.chkProfileRepDir = new System.Windows.Forms.CheckBox();
            this.grpSession = new System.Windows.Forms.GroupBox();
            this.lblSessionInfo = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.grpSettings.SuspendLayout();
            this.grpAccInfo.SuspendLayout();
            this.grpChangePass.SuspendLayout();
            this.grpNotificationsPref.SuspendLayout();
            this.grpProfileVisbility.SuspendLayout();
            this.grpSession.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpSettings
            // 
            this.grpSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.grpSettings.Controls.Add(this.lblSettingsDescription);
            this.grpSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSettings.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpSettings.Location = new System.Drawing.Point(12, 12);
            this.grpSettings.Name = "grpSettings";
            this.grpSettings.Size = new System.Drawing.Size(1278, 88);
            this.grpSettings.TabIndex = 0;
            this.grpSettings.TabStop = false;
            this.grpSettings.Text = "Settings";
            // 
            // lblSettingsDescription
            // 
            this.lblSettingsDescription.AutoSize = true;
            this.lblSettingsDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettingsDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblSettingsDescription.Location = new System.Drawing.Point(10, 36);
            this.lblSettingsDescription.Name = "lblSettingsDescription";
            this.lblSettingsDescription.Size = new System.Drawing.Size(509, 18);
            this.lblSettingsDescription.TabIndex = 0;
            this.lblSettingsDescription.Text = "Manage your profile, security settings, and notification preferences";
            // 
            // grpAccInfo
            // 
            this.grpAccInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.grpAccInfo.Controls.Add(this.btnSaveChanges);
            this.grpAccInfo.Controls.Add(this.lblUsername);
            this.grpAccInfo.Controls.Add(this.lblEmail);
            this.grpAccInfo.Controls.Add(this.lblName);
            this.grpAccInfo.Controls.Add(this.txtUsername);
            this.grpAccInfo.Controls.Add(this.txtEmail);
            this.grpAccInfo.Controls.Add(this.txtFullName);
            this.grpAccInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAccInfo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpAccInfo.Location = new System.Drawing.Point(12, 106);
            this.grpAccInfo.Name = "grpAccInfo";
            this.grpAccInfo.Size = new System.Drawing.Size(657, 292);
            this.grpAccInfo.TabIndex = 1;
            this.grpAccInfo.TabStop = false;
            this.grpAccInfo.Text = "Edit Acoount Informtion";
            // 
            // btnSaveChanges
            // 
            this.btnSaveChanges.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(211)))), ((int)(((byte)(238)))));
            this.btnSaveChanges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveChanges.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(51)))), ((int)(((byte)(72)))));
            this.btnSaveChanges.Location = new System.Drawing.Point(18, 239);
            this.btnSaveChanges.Name = "btnSaveChanges";
            this.btnSaveChanges.Size = new System.Drawing.Size(155, 27);
            this.btnSaveChanges.TabIndex = 6;
            this.btnSaveChanges.Text = "Save Changes";
            this.btnSaveChanges.UseVisualStyleBackColor = false;
            this.btnSaveChanges.Click += new System.EventHandler(this.btnSaveChanges_Click);
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblUsername.Location = new System.Drawing.Point(15, 170);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(85, 18);
            this.lblUsername.TabIndex = 5;
            this.lblUsername.Text = "Username";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblEmail.Location = new System.Drawing.Point(15, 102);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(116, 18);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "Email Address";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblName.Location = new System.Drawing.Point(15, 38);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(84, 18);
            this.lblName.TabIndex = 3;
            this.lblName.Text = "Full Name";
            // 
            // txtUsername
            // 
            this.txtUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(19)))), ((int)(((byte)(32)))));
            this.txtUsername.ForeColor = System.Drawing.Color.White;
            this.txtUsername.Location = new System.Drawing.Point(18, 191);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(571, 27);
            this.txtUsername.TabIndex = 2;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(19)))), ((int)(((byte)(32)))));
            this.txtEmail.ForeColor = System.Drawing.Color.White;
            this.txtEmail.Location = new System.Drawing.Point(18, 123);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(571, 27);
            this.txtEmail.TabIndex = 1;
            // 
            // txtFullName
            // 
            this.txtFullName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(19)))), ((int)(((byte)(32)))));
            this.txtFullName.ForeColor = System.Drawing.Color.White;
            this.txtFullName.Location = new System.Drawing.Point(18, 59);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(571, 27);
            this.txtFullName.TabIndex = 0;
            // 
            // grpChangePass
            // 
            this.grpChangePass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.grpChangePass.Controls.Add(this.lblConfirmNewPass);
            this.grpChangePass.Controls.Add(this.lblNewPass);
            this.grpChangePass.Controls.Add(this.lblCurrentPass);
            this.grpChangePass.Controls.Add(this.btnUpdatePass);
            this.grpChangePass.Controls.Add(this.txtConfirmNewPass);
            this.grpChangePass.Controls.Add(this.txtNewPass);
            this.grpChangePass.Controls.Add(this.txtCurrentPass);
            this.grpChangePass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpChangePass.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpChangePass.Location = new System.Drawing.Point(12, 404);
            this.grpChangePass.Name = "grpChangePass";
            this.grpChangePass.Size = new System.Drawing.Size(657, 295);
            this.grpChangePass.TabIndex = 2;
            this.grpChangePass.TabStop = false;
            this.grpChangePass.Text = "Change Password";
            // 
            // lblConfirmNewPass
            // 
            this.lblConfirmNewPass.AutoSize = true;
            this.lblConfirmNewPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmNewPass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblConfirmNewPass.Location = new System.Drawing.Point(16, 171);
            this.lblConfirmNewPass.Name = "lblConfirmNewPass";
            this.lblConfirmNewPass.Size = new System.Drawing.Size(186, 18);
            this.lblConfirmNewPass.TabIndex = 10;
            this.lblConfirmNewPass.Text = "Confirm New Password";
            // 
            // lblNewPass
            // 
            this.lblNewPass.AutoSize = true;
            this.lblNewPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewPass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblNewPass.Location = new System.Drawing.Point(16, 103);
            this.lblNewPass.Name = "lblNewPass";
            this.lblNewPass.Size = new System.Drawing.Size(121, 18);
            this.lblNewPass.TabIndex = 9;
            this.lblNewPass.Text = "New Password";
            // 
            // lblCurrentPass
            // 
            this.lblCurrentPass.AutoSize = true;
            this.lblCurrentPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentPass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblCurrentPass.Location = new System.Drawing.Point(15, 37);
            this.lblCurrentPass.Name = "lblCurrentPass";
            this.lblCurrentPass.Size = new System.Drawing.Size(144, 18);
            this.lblCurrentPass.TabIndex = 8;
            this.lblCurrentPass.Text = "Current Password";
            // 
            // btnUpdatePass
            // 
            this.btnUpdatePass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(211)))), ((int)(((byte)(238)))));
            this.btnUpdatePass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdatePass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(51)))), ((int)(((byte)(72)))));
            this.btnUpdatePass.Location = new System.Drawing.Point(18, 245);
            this.btnUpdatePass.Name = "btnUpdatePass";
            this.btnUpdatePass.Size = new System.Drawing.Size(155, 27);
            this.btnUpdatePass.TabIndex = 7;
            this.btnUpdatePass.Text = "Update Password";
            this.btnUpdatePass.UseVisualStyleBackColor = false;
            this.btnUpdatePass.Click += new System.EventHandler(this.btnUpdatePass_Click);
            // 
            // txtConfirmNewPass
            // 
            this.txtConfirmNewPass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(19)))), ((int)(((byte)(32)))));
            this.txtConfirmNewPass.ForeColor = System.Drawing.Color.White;
            this.txtConfirmNewPass.Location = new System.Drawing.Point(18, 192);
            this.txtConfirmNewPass.Name = "txtConfirmNewPass";
            this.txtConfirmNewPass.PasswordChar = '*';
            this.txtConfirmNewPass.Size = new System.Drawing.Size(571, 27);
            this.txtConfirmNewPass.TabIndex = 5;
            // 
            // txtNewPass
            // 
            this.txtNewPass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(19)))), ((int)(((byte)(32)))));
            this.txtNewPass.ForeColor = System.Drawing.Color.White;
            this.txtNewPass.Location = new System.Drawing.Point(18, 124);
            this.txtNewPass.Name = "txtNewPass";
            this.txtNewPass.PasswordChar = '*';
            this.txtNewPass.Size = new System.Drawing.Size(571, 27);
            this.txtNewPass.TabIndex = 4;
            // 
            // txtCurrentPass
            // 
            this.txtCurrentPass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(19)))), ((int)(((byte)(32)))));
            this.txtCurrentPass.ForeColor = System.Drawing.Color.White;
            this.txtCurrentPass.Location = new System.Drawing.Point(18, 58);
            this.txtCurrentPass.Name = "txtCurrentPass";
            this.txtCurrentPass.PasswordChar = '*';
            this.txtCurrentPass.Size = new System.Drawing.Size(571, 27);
            this.txtCurrentPass.TabIndex = 3;
            // 
            // grpNotificationsPref
            // 
            this.grpNotificationsPref.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.grpNotificationsPref.Controls.Add(this.lblTransAlertInfo);
            this.grpNotificationsPref.Controls.Add(this.lblPushInfo);
            this.grpNotificationsPref.Controls.Add(this.lblEmailInfo);
            this.grpNotificationsPref.Controls.Add(this.chkTransAlerts);
            this.grpNotificationsPref.Controls.Add(this.chkPushNotis);
            this.grpNotificationsPref.Controls.Add(this.chkEmailNotis);
            this.grpNotificationsPref.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNotificationsPref.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpNotificationsPref.Location = new System.Drawing.Point(689, 106);
            this.grpNotificationsPref.Name = "grpNotificationsPref";
            this.grpNotificationsPref.Size = new System.Drawing.Size(601, 230);
            this.grpNotificationsPref.TabIndex = 3;
            this.grpNotificationsPref.TabStop = false;
            this.grpNotificationsPref.Text = "Notifications Preferences";
            // 
            // lblTransAlertInfo
            // 
            this.lblTransAlertInfo.AutoSize = true;
            this.lblTransAlertInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransAlertInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblTransAlertInfo.Location = new System.Drawing.Point(6, 174);
            this.lblTransAlertInfo.Name = "lblTransAlertInfo";
            this.lblTransAlertInfo.Size = new System.Drawing.Size(323, 18);
            this.lblTransAlertInfo.TabIndex = 11;
            this.lblTransAlertInfo.Text = "Get notified instantly on block-reputation actions";
            // 
            // lblPushInfo
            // 
            this.lblPushInfo.AutoSize = true;
            this.lblPushInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPushInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblPushInfo.Location = new System.Drawing.Point(6, 121);
            this.lblPushInfo.Name = "lblPushInfo";
            this.lblPushInfo.Size = new System.Drawing.Size(365, 18);
            this.lblPushInfo.TabIndex = 10;
            this.lblPushInfo.Text = "Alert me on the browser for verification status changes";
            // 
            // lblEmailInfo
            // 
            this.lblEmailInfo.AutoSize = true;
            this.lblEmailInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblEmailInfo.Location = new System.Drawing.Point(3, 67);
            this.lblEmailInfo.Name = "lblEmailInfo";
            this.lblEmailInfo.Size = new System.Drawing.Size(331, 18);
            this.lblEmailInfo.TabIndex = 9;
            this.lblEmailInfo.Text = "Receive security digests and login alerts via email";
            // 
            // chkTransAlerts
            // 
            this.chkTransAlerts.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkTransAlerts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTransAlerts.Location = new System.Drawing.Point(6, 145);
            this.chkTransAlerts.Name = "chkTransAlerts";
            this.chkTransAlerts.Size = new System.Drawing.Size(582, 47);
            this.chkTransAlerts.TabIndex = 2;
            this.chkTransAlerts.Text = "Transaction Alerts";
            this.chkTransAlerts.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkTransAlerts.UseVisualStyleBackColor = true;
            // 
            // chkPushNotis
            // 
            this.chkPushNotis.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkPushNotis.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPushNotis.Location = new System.Drawing.Point(6, 92);
            this.chkPushNotis.Name = "chkPushNotis";
            this.chkPushNotis.Size = new System.Drawing.Size(582, 47);
            this.chkPushNotis.TabIndex = 1;
            this.chkPushNotis.Text = "Push Notifications";
            this.chkPushNotis.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkPushNotis.UseVisualStyleBackColor = true;
            // 
            // chkEmailNotis
            // 
            this.chkEmailNotis.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkEmailNotis.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEmailNotis.Location = new System.Drawing.Point(6, 38);
            this.chkEmailNotis.Name = "chkEmailNotis";
            this.chkEmailNotis.Size = new System.Drawing.Size(582, 47);
            this.chkEmailNotis.TabIndex = 0;
            this.chkEmailNotis.Text = "Email Notifications";
            this.chkEmailNotis.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkEmailNotis.UseVisualStyleBackColor = true;
            // 
            // grpProfileVisbility
            // 
            this.grpProfileVisbility.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.grpProfileVisbility.Controls.Add(this.lblProfileRepInfo);
            this.grpProfileVisbility.Controls.Add(this.chkProfileRepDir);
            this.grpProfileVisbility.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpProfileVisbility.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpProfileVisbility.Location = new System.Drawing.Point(689, 358);
            this.grpProfileVisbility.Name = "grpProfileVisbility";
            this.grpProfileVisbility.Size = new System.Drawing.Size(601, 116);
            this.grpProfileVisbility.TabIndex = 4;
            this.grpProfileVisbility.TabStop = false;
            this.grpProfileVisbility.Text = "Profile Visibility";
            // 
            // lblProfileRepInfo
            // 
            this.lblProfileRepInfo.AutoSize = true;
            this.lblProfileRepInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfileRepInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblProfileRepInfo.Location = new System.Drawing.Point(6, 68);
            this.lblProfileRepInfo.Name = "lblProfileRepInfo";
            this.lblProfileRepInfo.Size = new System.Drawing.Size(450, 18);
            this.lblProfileRepInfo.TabIndex = 13;
            this.lblProfileRepInfo.Text = "Allow other verified companies to search and view your Trust Score";
            // 
            // chkProfileRepDir
            // 
            this.chkProfileRepDir.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkProfileRepDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProfileRepDir.Location = new System.Drawing.Point(6, 43);
            this.chkProfileRepDir.Name = "chkProfileRepDir";
            this.chkProfileRepDir.Size = new System.Drawing.Size(582, 47);
            this.chkProfileRepDir.TabIndex = 12;
            this.chkProfileRepDir.Text = "Profile Reputation Directory";
            this.chkProfileRepDir.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkProfileRepDir.UseVisualStyleBackColor = true;
            // 
            // grpSession
            // 
            this.grpSession.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.grpSession.Controls.Add(this.lblSessionInfo);
            this.grpSession.Controls.Add(this.btnLogout);
            this.grpSession.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSession.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpSession.Location = new System.Drawing.Point(689, 496);
            this.grpSession.Name = "grpSession";
            this.grpSession.Size = new System.Drawing.Size(601, 127);
            this.grpSession.TabIndex = 5;
            this.grpSession.TabStop = false;
            this.grpSession.Text = "Session";
            // 
            // lblSessionInfo
            // 
            this.lblSessionInfo.AutoSize = true;
            this.lblSessionInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSessionInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblSessionInfo.Location = new System.Drawing.Point(19, 41);
            this.lblSessionInfo.Name = "lblSessionInfo";
            this.lblSessionInfo.Size = new System.Drawing.Size(467, 18);
            this.lblSessionInfo.TabIndex = 11;
            this.lblSessionInfo.Text = "Disconnect and log out from your local TrustID node session";
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Red;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(22, 79);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(155, 27);
            this.btnLogout.TabIndex = 8;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // frmSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(15)))), ((int)(((byte)(26)))));
            this.ClientSize = new System.Drawing.Size(1302, 739);
            this.Controls.Add(this.grpSession);
            this.Controls.Add(this.grpProfileVisbility);
            this.Controls.Add(this.grpNotificationsPref);
            this.Controls.Add(this.grpChangePass);
            this.Controls.Add(this.grpAccInfo);
            this.Controls.Add(this.grpSettings);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSettings";
            this.Text = "Settings";
            this.grpSettings.ResumeLayout(false);
            this.grpSettings.PerformLayout();
            this.grpAccInfo.ResumeLayout(false);
            this.grpAccInfo.PerformLayout();
            this.grpChangePass.ResumeLayout(false);
            this.grpChangePass.PerformLayout();
            this.grpNotificationsPref.ResumeLayout(false);
            this.grpNotificationsPref.PerformLayout();
            this.grpProfileVisbility.ResumeLayout(false);
            this.grpProfileVisbility.PerformLayout();
            this.grpSession.ResumeLayout(false);
            this.grpSession.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpSettings;
        private System.Windows.Forms.GroupBox grpAccInfo;
        private System.Windows.Forms.GroupBox grpChangePass;
        private System.Windows.Forms.GroupBox grpNotificationsPref;
        private System.Windows.Forms.GroupBox grpProfileVisbility;
        private System.Windows.Forms.GroupBox grpSession;
        private System.Windows.Forms.Label lblSettingsDescription;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Button btnSaveChanges;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtConfirmNewPass;
        private System.Windows.Forms.TextBox txtNewPass;
        private System.Windows.Forms.TextBox txtCurrentPass;
        private System.Windows.Forms.Label lblConfirmNewPass;
        private System.Windows.Forms.Label lblNewPass;
        private System.Windows.Forms.Label lblCurrentPass;
        private System.Windows.Forms.Button btnUpdatePass;
        private System.Windows.Forms.CheckBox chkTransAlerts;
        private System.Windows.Forms.CheckBox chkPushNotis;
        private System.Windows.Forms.CheckBox chkEmailNotis;
        private System.Windows.Forms.Label lblTransAlertInfo;
        private System.Windows.Forms.Label lblPushInfo;
        private System.Windows.Forms.Label lblEmailInfo;
        private System.Windows.Forms.Label lblProfileRepInfo;
        private System.Windows.Forms.CheckBox chkProfileRepDir;
        private System.Windows.Forms.Label lblSessionInfo;
        private System.Windows.Forms.Button btnLogout;
    }
}

