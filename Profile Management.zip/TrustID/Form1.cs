﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProfileManagement
{
    public partial class frmSettings : Form
    {
        public frmSettings()
        {
            InitializeComponent();
            LoadAccountInfo();
        }

        private void LoadAccountInfo()
        {
            txtFullName.Text = ProfileInfo.FullName;
            txtEmail.Text = ProfileInfo.Email;
            txtUsername.Text = ProfileInfo.Username;
        }

        

        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            string FullName = txtFullName.Text.Trim();
            string Email = txtEmail.Text.Trim();
            string Username = txtUsername.Text.Trim();

            if(FullName.Length < 2)
            {
                MessageBox.Show(" Full Name cannot be less than 2 characters", "Full name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(string.IsNullOrEmpty(FullName) || string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Username))
            {
                MessageBox.Show("Please Fill in All information", "Information  missing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(!Email.Contains("@") || !Email.Contains("."))
            {
                MessageBox.Show("Please provide a valid email address", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ProfileInfo.FullName = FullName;
            ProfileInfo.Email = Email;
            ProfileInfo.Username = Username;

            MessageBox.Show("Account information saved", "Information saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnUpdatePass_Click(object sender, EventArgs e)
        {
            string CurrentPass = txtCurrentPass.Text;
            string NewPass = txtNewPass.Text;
            string ConfirmNewPass = txtConfirmNewPass.Text;

            if(string.IsNullOrEmpty(CurrentPass) || string.IsNullOrEmpty(NewPass) || string.IsNullOrEmpty(ConfirmNewPass))
            {
                MessageBox.Show("Please fill in all required information!", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (CurrentPass != ProfileInfo.Password)
            {
                MessageBox.Show("Please enter the correct password!", "Incorrect Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (NewPass.Length <= 8)
            {
                MessageBox.Show("New password must be at least 8 characters long", "New Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ConfirmNewPass != NewPass)
            {
                MessageBox.Show("New Password and confirmation do not match", "Password mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(NewPass == CurrentPass)
            {
                MessageBox.Show("New password cannot be the same as current password", "Enter New Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ProfileInfo.Password = NewPass;

            MessageBox.Show("Password Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtConfirmNewPass.Clear();
            txtCurrentPass.Clear();
            txtNewPass.Clear();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {

        }
    }
}
