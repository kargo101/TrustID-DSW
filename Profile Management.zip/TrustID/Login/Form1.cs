namespace Login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string idNumber = txtName.Text.Trim();
            if (string.IsNullOrEmpty(idNumber))
            {
                MessageBox.Show("Please enter your ID number");
            }
            if (idNumber.Length!=13)
            {
                MessageBox.Show("Please enter a valid 13-digit ID number");
            }

        }
    }
}
