﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ProfileManagement
{
    internal class ProfileInfo
    {
        public static string FullName { get; set; } = "";
        public static string Email { get; set; } = "";
        public static string Username { get; set; } = "";
        public static string Password { get; set; } = "password";
    }
}
