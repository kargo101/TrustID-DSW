﻿namespace ProfileManagement
{
    partial class UcQualifications
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDateIssued = new System.Windows.Forms.TextBox();
            this.lblDate6 = new System.Windows.Forms.Label();
            this.pnlQualification2 = new System.Windows.Forms.Panel();
            this.lblDate2 = new System.Windows.Forms.Label();
            this.lblInstitution2 = new System.Windows.Forms.Label();
            this.lblQualification2 = new System.Windows.Forms.Label();
            this.pnlQualification6 = new System.Windows.Forms.Panel();
            this.lblInstitution6 = new System.Windows.Forms.Label();
            this.lblQualification6 = new System.Windows.Forms.Label();
            this.lblDate3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAddQualification = new System.Windows.Forms.Button();
            this.lblDateIssued = new System.Windows.Forms.Label();
            this.lblInstitutionName = new System.Windows.Forms.Label();
            this.lblQualification = new System.Windows.Forms.Label();
            this.txtInstitution = new System.Windows.Forms.TextBox();
            this.txtQualification = new System.Windows.Forms.TextBox();
            this.lblInstitution3 = new System.Windows.Forms.Label();
            this.btnBackButton = new System.Windows.Forms.Button();
            this.lblQualificationsDescription = new System.Windows.Forms.Label();
            this.lblDate1 = new System.Windows.Forms.Label();
            this.lblInstitution1 = new System.Windows.Forms.Label();
            this.lblQualification1 = new System.Windows.Forms.Label();
            this.lblInstitution5 = new System.Windows.Forms.Label();
            this.pnlQualification5 = new System.Windows.Forms.Panel();
            this.lblDate5 = new System.Windows.Forms.Label();
            this.lblQualification5 = new System.Windows.Forms.Label();
            this.pnlQualification3 = new System.Windows.Forms.Panel();
            this.lblQualification3 = new System.Windows.Forms.Label();
            this.lblDate4 = new System.Windows.Forms.Label();
            this.pnlQualification4 = new System.Windows.Forms.Panel();
            this.lblInstitution4 = new System.Windows.Forms.Label();
            this.lblQualification4 = new System.Windows.Forms.Label();
            this.pnlQualification1 = new System.Windows.Forms.Panel();
            this.grpQualificationsAndCred = new System.Windows.Forms.GroupBox();
            this.pnlQualification2.SuspendLayout();
            this.pnlQualification6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnlQualification5.SuspendLayout();
            this.pnlQualification3.SuspendLayout();
            this.pnlQualification4.SuspendLayout();
            this.pnlQualification1.SuspendLayout();
            this.grpQualificationsAndCred.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtDateIssued
            // 
            this.txtDateIssued.Location = new System.Drawing.Point(29, 200);
            this.txtDateIssued.Name = "txtDateIssued";
            this.txtDateIssued.Size = new System.Drawing.Size(405, 27);
            this.txtDateIssued.TabIndex = 1;
            // 
            // lblDate6
            // 
            this.lblDate6.AutoSize = true;
            this.lblDate6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblDate6.Location = new System.Drawing.Point(31, 105);
            this.lblDate6.Name = "lblDate6";
            this.lblDate6.Size = new System.Drawing.Size(135, 18);
            this.lblDate6.TabIndex = 6;
            this.lblDate6.Text = "Issued: Month Year";
            // 
            // pnlQualification2
            // 
            this.pnlQualification2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.pnlQualification2.Controls.Add(this.lblDate2);
            this.pnlQualification2.Controls.Add(this.lblInstitution2);
            this.pnlQualification2.Controls.Add(this.lblQualification2);
            this.pnlQualification2.Location = new System.Drawing.Point(390, 135);
            this.pnlQualification2.Name = "pnlQualification2";
            this.pnlQualification2.Size = new System.Drawing.Size(340, 142);
            this.pnlQualification2.TabIndex = 8;
            // 
            // lblDate2
            // 
            this.lblDate2.AutoSize = true;
            this.lblDate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblDate2.Location = new System.Drawing.Point(33, 94);
            this.lblDate2.Name = "lblDate2";
            this.lblDate2.Size = new System.Drawing.Size(135, 18);
            this.lblDate2.TabIndex = 10;
            this.lblDate2.Text = "Issued: Month Year";
            // 
            // lblInstitution2
            // 
            this.lblInstitution2.AutoSize = true;
            this.lblInstitution2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitution2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblInstitution2.Location = new System.Drawing.Point(33, 58);
            this.lblInstitution2.Name = "lblInstitution2";
            this.lblInstitution2.Size = new System.Drawing.Size(95, 18);
            this.lblInstitution2.TabIndex = 5;
            this.lblInstitution2.Text = "Institution 2";
            // 
            // lblQualification2
            // 
            this.lblQualification2.AutoSize = true;
            this.lblQualification2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualification2.ForeColor = System.Drawing.SystemColors.Control;
            this.lblQualification2.Location = new System.Drawing.Point(32, 21);
            this.lblQualification2.Name = "lblQualification2";
            this.lblQualification2.Size = new System.Drawing.Size(131, 20);
            this.lblQualification2.TabIndex = 1;
            this.lblQualification2.Text = "Qualification 2";
            // 
            // pnlQualification6
            // 
            this.pnlQualification6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.pnlQualification6.Controls.Add(this.lblDate6);
            this.pnlQualification6.Controls.Add(this.lblInstitution6);
            this.pnlQualification6.Controls.Add(this.lblQualification6);
            this.pnlQualification6.Location = new System.Drawing.Point(390, 503);
            this.pnlQualification6.Name = "pnlQualification6";
            this.pnlQualification6.Size = new System.Drawing.Size(340, 142);
            this.pnlQualification6.TabIndex = 9;
            // 
            // lblInstitution6
            // 
            this.lblInstitution6.AutoSize = true;
            this.lblInstitution6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitution6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblInstitution6.Location = new System.Drawing.Point(32, 58);
            this.lblInstitution6.Name = "lblInstitution6";
            this.lblInstitution6.Size = new System.Drawing.Size(95, 18);
            this.lblInstitution6.TabIndex = 5;
            this.lblInstitution6.Text = "Institution 6";
            // 
            // lblQualification6
            // 
            this.lblQualification6.AutoSize = true;
            this.lblQualification6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualification6.ForeColor = System.Drawing.SystemColors.Control;
            this.lblQualification6.Location = new System.Drawing.Point(31, 19);
            this.lblQualification6.Name = "lblQualification6";
            this.lblQualification6.Size = new System.Drawing.Size(131, 20);
            this.lblQualification6.TabIndex = 1;
            this.lblQualification6.Text = "Qualification 6";
            // 
            // lblDate3
            // 
            this.lblDate3.AutoSize = true;
            this.lblDate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblDate3.Location = new System.Drawing.Point(31, 102);
            this.lblDate3.Name = "lblDate3";
            this.lblDate3.Size = new System.Drawing.Size(135, 18);
            this.lblDate3.TabIndex = 8;
            this.lblDate3.Text = "Issued: Month Year";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.groupBox1.Controls.Add(this.btnAddQualification);
            this.groupBox1.Controls.Add(this.lblDateIssued);
            this.groupBox1.Controls.Add(this.lblInstitutionName);
            this.groupBox1.Controls.Add(this.lblQualification);
            this.groupBox1.Controls.Add(this.txtInstitution);
            this.groupBox1.Controls.Add(this.txtDateIssued);
            this.groupBox1.Controls.Add(this.txtQualification);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Location = new System.Drawing.Point(783, 135);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(487, 319);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Qualification";
            // 
            // btnAddQualification
            // 
            this.btnAddQualification.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(211)))), ((int)(((byte)(238)))));
            this.btnAddQualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddQualification.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(51)))), ((int)(((byte)(72)))));
            this.btnAddQualification.Location = new System.Drawing.Point(29, 255);
            this.btnAddQualification.Name = "btnAddQualification";
            this.btnAddQualification.Size = new System.Drawing.Size(139, 26);
            this.btnAddQualification.TabIndex = 8;
            this.btnAddQualification.Text = "Add Qualification";
            this.btnAddQualification.UseVisualStyleBackColor = false;
            this.btnAddQualification.Click += new System.EventHandler(this.btnAddQualification_Click);
            // 
            // lblDateIssued
            // 
            this.lblDateIssued.AutoSize = true;
            this.lblDateIssued.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateIssued.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblDateIssued.Location = new System.Drawing.Point(26, 179);
            this.lblDateIssued.Name = "lblDateIssued";
            this.lblDateIssued.Size = new System.Drawing.Size(97, 18);
            this.lblDateIssued.TabIndex = 7;
            this.lblDateIssued.Text = "Date Issued";
            // 
            // lblInstitutionName
            // 
            this.lblInstitutionName.AutoSize = true;
            this.lblInstitutionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitutionName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblInstitutionName.Location = new System.Drawing.Point(26, 109);
            this.lblInstitutionName.Name = "lblInstitutionName";
            this.lblInstitutionName.Size = new System.Drawing.Size(86, 18);
            this.lblInstitutionName.TabIndex = 6;
            this.lblInstitutionName.Text = "Institution ";
            // 
            // lblQualification
            // 
            this.lblQualification.AutoSize = true;
            this.lblQualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualification.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblQualification.Location = new System.Drawing.Point(26, 32);
            this.lblQualification.Name = "lblQualification";
            this.lblQualification.Size = new System.Drawing.Size(102, 18);
            this.lblQualification.TabIndex = 5;
            this.lblQualification.Text = "Qualification";
            // 
            // txtInstitution
            // 
            this.txtInstitution.Location = new System.Drawing.Point(29, 130);
            this.txtInstitution.Name = "txtInstitution";
            this.txtInstitution.Size = new System.Drawing.Size(405, 27);
            this.txtInstitution.TabIndex = 2;
            // 
            // txtQualification
            // 
            this.txtQualification.Location = new System.Drawing.Point(29, 60);
            this.txtQualification.Name = "txtQualification";
            this.txtQualification.Size = new System.Drawing.Size(405, 27);
            this.txtQualification.TabIndex = 0;
            // 
            // lblInstitution3
            // 
            this.lblInstitution3.AutoSize = true;
            this.lblInstitution3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitution3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblInstitution3.Location = new System.Drawing.Point(32, 58);
            this.lblInstitution3.Name = "lblInstitution3";
            this.lblInstitution3.Size = new System.Drawing.Size(95, 18);
            this.lblInstitution3.TabIndex = 5;
            this.lblInstitution3.Text = "Institution 3";
            // 
            // btnBackButton
            // 
            this.btnBackButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(211)))), ((int)(((byte)(238)))));
            this.btnBackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(51)))), ((int)(((byte)(72)))));
            this.btnBackButton.Location = new System.Drawing.Point(-85, 630);
            this.btnBackButton.Name = "btnBackButton";
            this.btnBackButton.Size = new System.Drawing.Size(75, 23);
            this.btnBackButton.TabIndex = 14;
            this.btnBackButton.Text = "Back ";
            this.btnBackButton.UseVisualStyleBackColor = false;
            // 
            // lblQualificationsDescription
            // 
            this.lblQualificationsDescription.AutoSize = true;
            this.lblQualificationsDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualificationsDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblQualificationsDescription.Location = new System.Drawing.Point(6, 48);
            this.lblQualificationsDescription.Name = "lblQualificationsDescription";
            this.lblQualificationsDescription.Size = new System.Drawing.Size(478, 18);
            this.lblQualificationsDescription.TabIndex = 0;
            this.lblQualificationsDescription.Text = "Showcase verified diplomas, active certifications, and honours";
            // 
            // lblDate1
            // 
            this.lblDate1.AutoSize = true;
            this.lblDate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblDate1.Location = new System.Drawing.Point(32, 94);
            this.lblDate1.Name = "lblDate1";
            this.lblDate1.Size = new System.Drawing.Size(135, 18);
            this.lblDate1.TabIndex = 5;
            this.lblDate1.Text = "Issued: Month Year";
            // 
            // lblInstitution1
            // 
            this.lblInstitution1.AutoSize = true;
            this.lblInstitution1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitution1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblInstitution1.Location = new System.Drawing.Point(31, 58);
            this.lblInstitution1.Name = "lblInstitution1";
            this.lblInstitution1.Size = new System.Drawing.Size(95, 18);
            this.lblInstitution1.TabIndex = 4;
            this.lblInstitution1.Text = "Institution 1";
            // 
            // lblQualification1
            // 
            this.lblQualification1.AutoSize = true;
            this.lblQualification1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualification1.ForeColor = System.Drawing.SystemColors.Control;
            this.lblQualification1.Location = new System.Drawing.Point(30, 21);
            this.lblQualification1.Name = "lblQualification1";
            this.lblQualification1.Size = new System.Drawing.Size(131, 20);
            this.lblQualification1.TabIndex = 0;
            this.lblQualification1.Text = "Qualification 1";
            // 
            // lblInstitution5
            // 
            this.lblInstitution5.AutoSize = true;
            this.lblInstitution5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitution5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblInstitution5.Location = new System.Drawing.Point(33, 58);
            this.lblInstitution5.Name = "lblInstitution5";
            this.lblInstitution5.Size = new System.Drawing.Size(95, 18);
            this.lblInstitution5.TabIndex = 5;
            this.lblInstitution5.Text = "Institution 5";
            // 
            // pnlQualification5
            // 
            this.pnlQualification5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.pnlQualification5.Controls.Add(this.lblInstitution5);
            this.pnlQualification5.Controls.Add(this.lblDate5);
            this.pnlQualification5.Controls.Add(this.lblQualification5);
            this.pnlQualification5.Location = new System.Drawing.Point(20, 503);
            this.pnlQualification5.Name = "pnlQualification5";
            this.pnlQualification5.Size = new System.Drawing.Size(340, 142);
            this.pnlQualification5.TabIndex = 10;
            // 
            // lblDate5
            // 
            this.lblDate5.AutoSize = true;
            this.lblDate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblDate5.Location = new System.Drawing.Point(31, 105);
            this.lblDate5.Name = "lblDate5";
            this.lblDate5.Size = new System.Drawing.Size(135, 18);
            this.lblDate5.TabIndex = 7;
            this.lblDate5.Text = "Issued: Month Year";
            // 
            // lblQualification5
            // 
            this.lblQualification5.AutoSize = true;
            this.lblQualification5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualification5.ForeColor = System.Drawing.SystemColors.Control;
            this.lblQualification5.Location = new System.Drawing.Point(32, 19);
            this.lblQualification5.Name = "lblQualification5";
            this.lblQualification5.Size = new System.Drawing.Size(131, 20);
            this.lblQualification5.TabIndex = 1;
            this.lblQualification5.Text = "Qualification 5";
            // 
            // pnlQualification3
            // 
            this.pnlQualification3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.pnlQualification3.Controls.Add(this.lblDate3);
            this.pnlQualification3.Controls.Add(this.lblInstitution3);
            this.pnlQualification3.Controls.Add(this.lblQualification3);
            this.pnlQualification3.Location = new System.Drawing.Point(20, 312);
            this.pnlQualification3.Name = "pnlQualification3";
            this.pnlQualification3.Size = new System.Drawing.Size(340, 142);
            this.pnlQualification3.TabIndex = 11;
            // 
            // lblQualification3
            // 
            this.lblQualification3.AutoSize = true;
            this.lblQualification3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualification3.ForeColor = System.Drawing.SystemColors.Control;
            this.lblQualification3.Location = new System.Drawing.Point(31, 21);
            this.lblQualification3.Name = "lblQualification3";
            this.lblQualification3.Size = new System.Drawing.Size(131, 20);
            this.lblQualification3.TabIndex = 1;
            this.lblQualification3.Text = "Qualification 3";
            // 
            // lblDate4
            // 
            this.lblDate4.AutoSize = true;
            this.lblDate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblDate4.Location = new System.Drawing.Point(33, 102);
            this.lblDate4.Name = "lblDate4";
            this.lblDate4.Size = new System.Drawing.Size(135, 18);
            this.lblDate4.TabIndex = 9;
            this.lblDate4.Text = "Issued: Month Year";
            // 
            // pnlQualification4
            // 
            this.pnlQualification4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.pnlQualification4.Controls.Add(this.lblDate4);
            this.pnlQualification4.Controls.Add(this.lblInstitution4);
            this.pnlQualification4.Controls.Add(this.lblQualification4);
            this.pnlQualification4.Location = new System.Drawing.Point(390, 312);
            this.pnlQualification4.Name = "pnlQualification4";
            this.pnlQualification4.Size = new System.Drawing.Size(340, 142);
            this.pnlQualification4.TabIndex = 12;
            // 
            // lblInstitution4
            // 
            this.lblInstitution4.AutoSize = true;
            this.lblInstitution4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitution4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(148)))), ((int)(((byte)(166)))));
            this.lblInstitution4.Location = new System.Drawing.Point(31, 58);
            this.lblInstitution4.Name = "lblInstitution4";
            this.lblInstitution4.Size = new System.Drawing.Size(95, 18);
            this.lblInstitution4.TabIndex = 5;
            this.lblInstitution4.Text = "Institution 4";
            // 
            // lblQualification4
            // 
            this.lblQualification4.AutoSize = true;
            this.lblQualification4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualification4.ForeColor = System.Drawing.SystemColors.Control;
            this.lblQualification4.Location = new System.Drawing.Point(30, 19);
            this.lblQualification4.Name = "lblQualification4";
            this.lblQualification4.Size = new System.Drawing.Size(131, 20);
            this.lblQualification4.TabIndex = 1;
            this.lblQualification4.Text = "Qualification 4";
            // 
            // pnlQualification1
            // 
            this.pnlQualification1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.pnlQualification1.Controls.Add(this.lblDate1);
            this.pnlQualification1.Controls.Add(this.lblInstitution1);
            this.pnlQualification1.Controls.Add(this.lblQualification1);
            this.pnlQualification1.Location = new System.Drawing.Point(20, 135);
            this.pnlQualification1.Name = "pnlQualification1";
            this.pnlQualification1.Size = new System.Drawing.Size(340, 142);
            this.pnlQualification1.TabIndex = 7;
            // 
            // grpQualificationsAndCred
            // 
            this.grpQualificationsAndCred.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
            this.grpQualificationsAndCred.Controls.Add(this.lblQualificationsDescription);
            this.grpQualificationsAndCred.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpQualificationsAndCred.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpQualificationsAndCred.Location = new System.Drawing.Point(11, 3);
            this.grpQualificationsAndCred.Name = "grpQualificationsAndCred";
            this.grpQualificationsAndCred.Size = new System.Drawing.Size(1298, 97);
            this.grpQualificationsAndCred.TabIndex = 6;
            this.grpQualificationsAndCred.TabStop = false;
            this.grpQualificationsAndCred.Text = "Qualifications And Credentials";
            // 
            // UcQualifications
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(15)))), ((int)(((byte)(26)))));
            this.Controls.Add(this.pnlQualification2);
            this.Controls.Add(this.pnlQualification6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnBackButton);
            this.Controls.Add(this.pnlQualification5);
            this.Controls.Add(this.pnlQualification3);
            this.Controls.Add(this.pnlQualification4);
            this.Controls.Add(this.pnlQualification1);
            this.Controls.Add(this.grpQualificationsAndCred);
            this.Name = "UcQualifications";
            this.Size = new System.Drawing.Size(1342, 703);
            this.pnlQualification2.ResumeLayout(false);
            this.pnlQualification2.PerformLayout();
            this.pnlQualification6.ResumeLayout(false);
            this.pnlQualification6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnlQualification5.ResumeLayout(false);
            this.pnlQualification5.PerformLayout();
            this.pnlQualification3.ResumeLayout(false);
            this.pnlQualification3.PerformLayout();
            this.pnlQualification4.ResumeLayout(false);
            this.pnlQualification4.PerformLayout();
            this.pnlQualification1.ResumeLayout(false);
            this.pnlQualification1.PerformLayout();
            this.grpQualificationsAndCred.ResumeLayout(false);
            this.grpQualificationsAndCred.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtDateIssued;
        private System.Windows.Forms.Label lblDate6;
        private System.Windows.Forms.Panel pnlQualification2;
        private System.Windows.Forms.Label lblDate2;
        private System.Windows.Forms.Label lblInstitution2;
        private System.Windows.Forms.Label lblQualification2;
        private System.Windows.Forms.Panel pnlQualification6;
        private System.Windows.Forms.Label lblInstitution6;
        private System.Windows.Forms.Label lblQualification6;
        private System.Windows.Forms.Label lblDate3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAddQualification;
        private System.Windows.Forms.Label lblDateIssued;
        private System.Windows.Forms.Label lblInstitutionName;
        private System.Windows.Forms.Label lblQualification;
        private System.Windows.Forms.TextBox txtInstitution;
        private System.Windows.Forms.TextBox txtQualification;
        private System.Windows.Forms.Label lblInstitution3;
        private System.Windows.Forms.Button btnBackButton;
        private System.Windows.Forms.Label lblQualificationsDescription;
        private System.Windows.Forms.Label lblDate1;
        private System.Windows.Forms.Label lblInstitution1;
        private System.Windows.Forms.Label lblQualification1;
        private System.Windows.Forms.Label lblInstitution5;
        private System.Windows.Forms.Panel pnlQualification5;
        private System.Windows.Forms.Label lblDate5;
        private System.Windows.Forms.Label lblQualification5;
        private System.Windows.Forms.Panel pnlQualification3;
        private System.Windows.Forms.Label lblQualification3;
        private System.Windows.Forms.Label lblDate4;
        private System.Windows.Forms.Panel pnlQualification4;
        private System.Windows.Forms.Label lblInstitution4;
        private System.Windows.Forms.Label lblQualification4;
        private System.Windows.Forms.Panel pnlQualification1;
        private System.Windows.Forms.GroupBox grpQualificationsAndCred;
    }
}
