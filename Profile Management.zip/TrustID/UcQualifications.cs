﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProfileManagement
{
    public partial class UcQualifications : UserControl
    {

        private Panel[] qualificationPanels;
        private Label[] qualificationLabels;
        private Label[] institutuionLabels;
        private Label[] dateLabels;
        private int nextSlotIndex = 0;


        public UcQualifications()
        {
            InitializeComponent();
        }

        private void SetupPanelArrays()
        {
            qualificationPanels = new Panel[]
            {
                pnlQualification1, pnlQualification2, pnlQualification3,
                pnlQualification4, pnlQualification5, pnlQualification6
            };

            qualificationLabels = new Label[]
            {
                lblQualification1, lblQualification2, lblQualification3,
                lblQualification4, lblQualification5, lblQualification6
            };

            institutuionLabels = new Label[]
            {
                lblInstitution1, lblInstitution2, lblInstitution3,
                lblInstitution4, lblInstitution5, lblInstitution6
            };

            dateLabels = new Label[]
            {
                lblDate1, lblDate2, lblDate3,
                lblDate4, lblDate5, lblDate6
            };



        }

        private void btnAddQualification_Click(object sender, EventArgs e)
        {
            string qualification = txtQualification.Text.Trim();
            string institution = txtInstitution.Text.Trim();
            string dateIssued = txtDateIssued.Text.Trim();

            if (string.IsNullOrEmpty(qualification) || string.IsNullOrEmpty(institution))
            {
                MessageBox.Show("Please fill in qualification and institution", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (nextSlotIndex >= qualificationPanels.Length)
            {
                MessageBox.Show("All qualification panels are full.", "Panel Full", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            qualificationLabels[nextSlotIndex].Text = qualification;
            institutuionLabels[nextSlotIndex].Text = institution;
            dateLabels[nextSlotIndex].Text = "Issued: " + (string.IsNullOrEmpty(dateIssued) ? "Unknown" : dateIssued);

            nextSlotIndex++;

            txtQualification.Clear();
            txtInstitution.Clear();
            txtDateIssued.Clear();
            txtQualification.Focus();

        }
    }
}
