﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Public_Reputation_Profile
{
    public class IndividualUser
    {
        public string phone { get; set; }
        public string Location { get; set; }
        public double TrustScore { get; set; }
        public bool IsVerified { get; set; }
        public List<string> Qualifications { get; set; } = new List<string>();
    }
}
