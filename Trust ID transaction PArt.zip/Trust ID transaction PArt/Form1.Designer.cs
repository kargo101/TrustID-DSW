﻿namespace Trust_ID_transaction_PArt
{
    partial class frmTransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlContent = new System.Windows.Forms.Panel();
            this.btnReviews = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTrustName = new System.Windows.Forms.Label();
            this.pnlCounterParty = new System.Windows.Forms.Panel();
            this.btnSubmittInformation = new System.Windows.Forms.Button();
            this.btnClearInfo = new System.Windows.Forms.Button();
            this.lblDisplayDescription = new System.Windows.Forms.Label();
            this.lblCompleteDescription = new System.Windows.Forms.Label();
            this.btnSubmittDescription = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.btnEnterAmount = new System.Windows.Forms.Button();
            this.txtReward = new System.Windows.Forms.TextBox();
            this.lblRewards = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtCounterSearch = new System.Windows.Forms.TextBox();
            this.lblCounterPartyLookup = new System.Windows.Forms.Label();
            this.dtpExecution = new System.Windows.Forms.DateTimePicker();
            this.cmbTransactionType = new System.Windows.Forms.ComboBox();
            this.lblDateOfExecution = new System.Windows.Forms.Label();
            this.lblTransactionType = new System.Windows.Forms.Label();
            this.lblTranasactionType = new System.Windows.Forms.Label();
            this.erpValidatior = new System.Windows.Forms.ErrorProvider(this.components);
            this.pnlSelectedCounterParty = new System.Windows.Forms.Panel();
            this.pnlPartyScore = new System.Windows.Forms.Panel();
            this.lblPartyScore = new System.Windows.Forms.Label();
            this.pnlLine1 = new System.Windows.Forms.Panel();
            this.lblSelectedUserJobtitle = new System.Windows.Forms.Label();
            this.lblSelectedUser = new System.Windows.Forms.Label();
            this.ptbSelectedParty = new System.Windows.Forms.PictureBox();
            this.lblSelectedCounterParty = new System.Windows.Forms.Label();
            this.btnTransactionHistory = new System.Windows.Forms.Button();
            this.pnlTreansactionsHeader = new System.Windows.Forms.Panel();
            this.ptbIcon = new System.Windows.Forms.PictureBox();
            this.lblMakeTransactionHeader = new System.Windows.Forms.Label();
            this.txtDisplayEnteredInfor = new System.Windows.Forms.TextBox();
            this.pnlContent.SuspendLayout();
            this.pnlCounterParty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erpValidatior)).BeginInit();
            this.pnlSelectedCounterParty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbSelectedParty)).BeginInit();
            this.pnlTreansactionsHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlContent
            // 
            this.pnlContent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(25)))), ((int)(((byte)(43)))));
            this.pnlContent.Controls.Add(this.btnReviews);
            this.pnlContent.Controls.Add(this.panel1);
            this.pnlContent.Controls.Add(this.lblTrustName);
            this.pnlContent.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlContent.ForeColor = System.Drawing.Color.White;
            this.pnlContent.Location = new System.Drawing.Point(0, 0);
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.Size = new System.Drawing.Size(232, 614);
            this.pnlContent.TabIndex = 0;
            // 
            // btnReviews
            // 
            this.btnReviews.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReviews.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviews.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnReviews.Location = new System.Drawing.Point(12, 240);
            this.btnReviews.Name = "btnReviews";
            this.btnReviews.Size = new System.Drawing.Size(204, 35);
            this.btnReviews.TabIndex = 2;
            this.btnReviews.Text = "Reviews";
            this.btnReviews.UseVisualStyleBackColor = true;
            this.btnReviews.Click += new System.EventHandler(this.btnReviews_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(254, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(494, 472);
            this.panel1.TabIndex = 1;
            // 
            // lblTrustName
            // 
            this.lblTrustName.AutoSize = true;
            this.lblTrustName.BackColor = System.Drawing.Color.Transparent;
            this.lblTrustName.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrustName.Location = new System.Drawing.Point(23, 12);
            this.lblTrustName.Name = "lblTrustName";
            this.lblTrustName.Size = new System.Drawing.Size(129, 41);
            this.lblTrustName.TabIndex = 0;
            this.lblTrustName.Text = "Trust ID";
            // 
            // pnlCounterParty
            // 
            this.pnlCounterParty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(28)))), ((int)(((byte)(47)))));
            this.pnlCounterParty.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlCounterParty.Controls.Add(this.btnSubmittInformation);
            this.pnlCounterParty.Controls.Add(this.btnClearInfo);
            this.pnlCounterParty.Controls.Add(this.lblDisplayDescription);
            this.pnlCounterParty.Controls.Add(this.lblCompleteDescription);
            this.pnlCounterParty.Controls.Add(this.btnSubmittDescription);
            this.pnlCounterParty.Controls.Add(this.txtDescription);
            this.pnlCounterParty.Controls.Add(this.lblDescription);
            this.pnlCounterParty.Controls.Add(this.btnEnterAmount);
            this.pnlCounterParty.Controls.Add(this.txtReward);
            this.pnlCounterParty.Controls.Add(this.lblRewards);
            this.pnlCounterParty.Controls.Add(this.btnSearch);
            this.pnlCounterParty.Controls.Add(this.txtCounterSearch);
            this.pnlCounterParty.Controls.Add(this.lblCounterPartyLookup);
            this.pnlCounterParty.Controls.Add(this.dtpExecution);
            this.pnlCounterParty.Controls.Add(this.cmbTransactionType);
            this.pnlCounterParty.Controls.Add(this.lblDateOfExecution);
            this.pnlCounterParty.Controls.Add(this.lblTransactionType);
            this.pnlCounterParty.Controls.Add(this.lblTranasactionType);
            this.pnlCounterParty.Location = new System.Drawing.Point(267, 74);
            this.pnlCounterParty.Name = "pnlCounterParty";
            this.pnlCounterParty.Size = new System.Drawing.Size(588, 512);
            this.pnlCounterParty.TabIndex = 1;
            // 
            // btnSubmittInformation
            // 
            this.btnSubmittInformation.BackColor = System.Drawing.Color.Cyan;
            this.btnSubmittInformation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmittInformation.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmittInformation.Location = new System.Drawing.Point(30, 414);
            this.btnSubmittInformation.Name = "btnSubmittInformation";
            this.btnSubmittInformation.Size = new System.Drawing.Size(137, 49);
            this.btnSubmittInformation.TabIndex = 13;
            this.btnSubmittInformation.Text = "Submitt Information";
            this.btnSubmittInformation.UseVisualStyleBackColor = false;
            this.btnSubmittInformation.Click += new System.EventHandler(this.btnSubmittInformation_Click);
            // 
            // btnClearInfo
            // 
            this.btnClearInfo.BackColor = System.Drawing.Color.Red;
            this.btnClearInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearInfo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearInfo.Location = new System.Drawing.Point(219, 414);
            this.btnClearInfo.Name = "btnClearInfo";
            this.btnClearInfo.Size = new System.Drawing.Size(161, 34);
            this.btnClearInfo.TabIndex = 12;
            this.btnClearInfo.Text = "Clear All";
            this.btnClearInfo.UseVisualStyleBackColor = false;
            this.btnClearInfo.Click += new System.EventHandler(this.btnClearInfo_Click);
            // 
            // lblDisplayDescription
            // 
            this.lblDisplayDescription.AutoSize = true;
            this.lblDisplayDescription.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayDescription.ForeColor = System.Drawing.Color.Transparent;
            this.lblDisplayDescription.Location = new System.Drawing.Point(114, 466);
            this.lblDisplayDescription.Name = "lblDisplayDescription";
            this.lblDisplayDescription.Size = new System.Drawing.Size(0, 17);
            this.lblDisplayDescription.TabIndex = 4;
            // 
            // lblCompleteDescription
            // 
            this.lblCompleteDescription.AutoSize = true;
            this.lblCompleteDescription.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompleteDescription.ForeColor = System.Drawing.Color.Transparent;
            this.lblCompleteDescription.Location = new System.Drawing.Point(27, 466);
            this.lblCompleteDescription.Name = "lblCompleteDescription";
            this.lblCompleteDescription.Size = new System.Drawing.Size(81, 17);
            this.lblCompleteDescription.TabIndex = 3;
            this.lblCompleteDescription.Text = "Description :";
            // 
            // btnSubmittDescription
            // 
            this.btnSubmittDescription.BackColor = System.Drawing.Color.Lime;
            this.btnSubmittDescription.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSubmittDescription.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmittDescription.ForeColor = System.Drawing.Color.Black;
            this.btnSubmittDescription.Location = new System.Drawing.Point(386, 414);
            this.btnSubmittDescription.Name = "btnSubmittDescription";
            this.btnSubmittDescription.Size = new System.Drawing.Size(161, 34);
            this.btnSubmittDescription.TabIndex = 11;
            this.btnSubmittDescription.Text = "Submitt Description";
            this.btnSubmittDescription.UseVisualStyleBackColor = false;
            this.btnSubmittDescription.Click += new System.EventHandler(this.btnSubmittDescription_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(30, 307);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(517, 100);
            this.txtDescription.TabIndex = 10;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.ForeColor = System.Drawing.Color.Transparent;
            this.lblDescription.Location = new System.Drawing.Point(30, 274);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(249, 20);
            this.lblDescription.TabIndex = 3;
            this.lblDescription.Text = "Milestone / Deliverable Descrtiption";
            // 
            // btnEnterAmount
            // 
            this.btnEnterAmount.BackColor = System.Drawing.Color.Aqua;
            this.btnEnterAmount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEnterAmount.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnterAmount.Location = new System.Drawing.Point(455, 211);
            this.btnEnterAmount.Name = "btnEnterAmount";
            this.btnEnterAmount.Size = new System.Drawing.Size(85, 49);
            this.btnEnterAmount.TabIndex = 9;
            this.btnEnterAmount.Text = "Enter Amount";
            this.btnEnterAmount.UseVisualStyleBackColor = false;
            this.btnEnterAmount.Click += new System.EventHandler(this.btnEnterAmount_Click);
            // 
            // txtReward
            // 
            this.txtReward.Location = new System.Drawing.Point(306, 183);
            this.txtReward.Name = "txtReward";
            this.txtReward.Size = new System.Drawing.Size(234, 22);
            this.txtReward.TabIndex = 8;
            // 
            // lblRewards
            // 
            this.lblRewards.AutoSize = true;
            this.lblRewards.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRewards.ForeColor = System.Drawing.Color.Transparent;
            this.lblRewards.Location = new System.Drawing.Point(306, 143);
            this.lblRewards.Name = "lblRewards";
            this.lblRewards.Size = new System.Drawing.Size(169, 20);
            this.lblRewards.TabIndex = 7;
            this.lblRewards.Text = "Value / Reward (Credits)";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Aqua;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(180, 211);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(85, 49);
            this.btnSearch.TabIndex = 6;
            this.btnSearch.Text = "Search Party";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtCounterSearch
            // 
            this.txtCounterSearch.Location = new System.Drawing.Point(34, 183);
            this.txtCounterSearch.Name = "txtCounterSearch";
            this.txtCounterSearch.Size = new System.Drawing.Size(231, 22);
            this.txtCounterSearch.TabIndex = 5;
            // 
            // lblCounterPartyLookup
            // 
            this.lblCounterPartyLookup.AutoSize = true;
            this.lblCounterPartyLookup.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCounterPartyLookup.ForeColor = System.Drawing.Color.Transparent;
            this.lblCounterPartyLookup.Location = new System.Drawing.Point(30, 143);
            this.lblCounterPartyLookup.Name = "lblCounterPartyLookup";
            this.lblCounterPartyLookup.Size = new System.Drawing.Size(150, 20);
            this.lblCounterPartyLookup.TabIndex = 2;
            this.lblCounterPartyLookup.Text = "Counter Party Lookup";
            // 
            // dtpExecution
            // 
            this.dtpExecution.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpExecution.Location = new System.Drawing.Point(306, 99);
            this.dtpExecution.MinDate = new System.DateTime(1800, 12, 31, 0, 0, 0, 0);
            this.dtpExecution.Name = "dtpExecution";
            this.dtpExecution.Size = new System.Drawing.Size(234, 22);
            this.dtpExecution.TabIndex = 4;
            this.dtpExecution.ValueChanged += new System.EventHandler(this.dtpExecution_ValueChanged);
            // 
            // cmbTransactionType
            // 
            this.cmbTransactionType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTransactionType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTransactionType.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTransactionType.ForeColor = System.Drawing.Color.Black;
            this.cmbTransactionType.FormattingEnabled = true;
            this.cmbTransactionType.Location = new System.Drawing.Point(34, 96);
            this.cmbTransactionType.Name = "cmbTransactionType";
            this.cmbTransactionType.Size = new System.Drawing.Size(231, 25);
            this.cmbTransactionType.TabIndex = 3;
            this.cmbTransactionType.SelectedIndexChanged += new System.EventHandler(this.cmbTransactionType_SelectedIndexChanged);
            // 
            // lblDateOfExecution
            // 
            this.lblDateOfExecution.AutoSize = true;
            this.lblDateOfExecution.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateOfExecution.ForeColor = System.Drawing.Color.Transparent;
            this.lblDateOfExecution.Location = new System.Drawing.Point(302, 55);
            this.lblDateOfExecution.Name = "lblDateOfExecution";
            this.lblDateOfExecution.Size = new System.Drawing.Size(145, 23);
            this.lblDateOfExecution.TabIndex = 2;
            this.lblDateOfExecution.Text = "Date of Execution";
            // 
            // lblTransactionType
            // 
            this.lblTransactionType.AutoSize = true;
            this.lblTransactionType.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionType.ForeColor = System.Drawing.Color.Transparent;
            this.lblTransactionType.Location = new System.Drawing.Point(30, 55);
            this.lblTransactionType.Name = "lblTransactionType";
            this.lblTransactionType.Size = new System.Drawing.Size(137, 23);
            this.lblTransactionType.TabIndex = 1;
            this.lblTransactionType.Text = "Transaction Type";
            // 
            // lblTranasactionType
            // 
            this.lblTranasactionType.AutoSize = true;
            this.lblTranasactionType.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTranasactionType.ForeColor = System.Drawing.Color.Transparent;
            this.lblTranasactionType.Location = new System.Drawing.Point(26, 17);
            this.lblTranasactionType.Name = "lblTranasactionType";
            this.lblTranasactionType.Size = new System.Drawing.Size(273, 24);
            this.lblTranasactionType.TabIndex = 0;
            this.lblTranasactionType.Text = "Reputation-Linked Transaction";
            // 
            // erpValidatior
            // 
            this.erpValidatior.ContainerControl = this;
            // 
            // pnlSelectedCounterParty
            // 
            this.pnlSelectedCounterParty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(28)))), ((int)(((byte)(47)))));
            this.pnlSelectedCounterParty.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSelectedCounterParty.Controls.Add(this.pnlPartyScore);
            this.pnlSelectedCounterParty.Controls.Add(this.lblPartyScore);
            this.pnlSelectedCounterParty.Controls.Add(this.pnlLine1);
            this.pnlSelectedCounterParty.Controls.Add(this.lblSelectedUserJobtitle);
            this.pnlSelectedCounterParty.Controls.Add(this.lblSelectedUser);
            this.pnlSelectedCounterParty.Controls.Add(this.ptbSelectedParty);
            this.pnlSelectedCounterParty.Controls.Add(this.lblSelectedCounterParty);
            this.pnlSelectedCounterParty.Location = new System.Drawing.Point(887, 74);
            this.pnlSelectedCounterParty.Name = "pnlSelectedCounterParty";
            this.pnlSelectedCounterParty.Size = new System.Drawing.Size(405, 442);
            this.pnlSelectedCounterParty.TabIndex = 2;
            // 
            // pnlPartyScore
            // 
            this.pnlPartyScore.Location = new System.Drawing.Point(89, 199);
            this.pnlPartyScore.Name = "pnlPartyScore";
            this.pnlPartyScore.Size = new System.Drawing.Size(151, 123);
            this.pnlPartyScore.TabIndex = 5;
            this.pnlPartyScore.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlPartyScore_Paint);
            // 
            // lblPartyScore
            // 
            this.lblPartyScore.AutoSize = true;
            this.lblPartyScore.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPartyScore.ForeColor = System.Drawing.Color.White;
            this.lblPartyScore.Location = new System.Drawing.Point(35, 211);
            this.lblPartyScore.Name = "lblPartyScore";
            this.lblPartyScore.Size = new System.Drawing.Size(48, 17);
            this.lblPartyScore.TabIndex = 4;
            this.lblPartyScore.Text = "Score :";
            // 
            // pnlLine1
            // 
            this.pnlLine1.BackColor = System.Drawing.Color.Lavender;
            this.pnlLine1.Location = new System.Drawing.Point(16, 183);
            this.pnlLine1.Name = "pnlLine1";
            this.pnlLine1.Size = new System.Drawing.Size(372, 10);
            this.pnlLine1.TabIndex = 4;
            // 
            // lblSelectedUserJobtitle
            // 
            this.lblSelectedUserJobtitle.AutoSize = true;
            this.lblSelectedUserJobtitle.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedUserJobtitle.ForeColor = System.Drawing.Color.White;
            this.lblSelectedUserJobtitle.Location = new System.Drawing.Point(155, 127);
            this.lblSelectedUserJobtitle.Name = "lblSelectedUserJobtitle";
            this.lblSelectedUserJobtitle.Size = new System.Drawing.Size(64, 17);
            this.lblSelectedUserJobtitle.TabIndex = 3;
            this.lblSelectedUserJobtitle.Text = "Job Title :";
            // 
            // lblSelectedUser
            // 
            this.lblSelectedUser.AutoSize = true;
            this.lblSelectedUser.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedUser.ForeColor = System.Drawing.Color.White;
            this.lblSelectedUser.Location = new System.Drawing.Point(155, 78);
            this.lblSelectedUser.Name = "lblSelectedUser";
            this.lblSelectedUser.Size = new System.Drawing.Size(50, 17);
            this.lblSelectedUser.TabIndex = 2;
            this.lblSelectedUser.Text = "Name :";
            // 
            // ptbSelectedParty
            // 
            this.ptbSelectedParty.Location = new System.Drawing.Point(38, 78);
            this.ptbSelectedParty.Name = "ptbSelectedParty";
            this.ptbSelectedParty.Size = new System.Drawing.Size(100, 87);
            this.ptbSelectedParty.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbSelectedParty.TabIndex = 1;
            this.ptbSelectedParty.TabStop = false;
            // 
            // lblSelectedCounterParty
            // 
            this.lblSelectedCounterParty.AutoSize = true;
            this.lblSelectedCounterParty.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedCounterParty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(165)))), ((int)(((byte)(186)))));
            this.lblSelectedCounterParty.Location = new System.Drawing.Point(35, 35);
            this.lblSelectedCounterParty.Name = "lblSelectedCounterParty";
            this.lblSelectedCounterParty.Size = new System.Drawing.Size(173, 17);
            this.lblSelectedCounterParty.TabIndex = 0;
            this.lblSelectedCounterParty.Text = "SELECTED COUNTERPARTY";
            // 
            // btnTransactionHistory
            // 
            this.btnTransactionHistory.BackColor = System.Drawing.Color.Aqua;
            this.btnTransactionHistory.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTransactionHistory.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactionHistory.Location = new System.Drawing.Point(887, 528);
            this.btnTransactionHistory.Name = "btnTransactionHistory";
            this.btnTransactionHistory.Size = new System.Drawing.Size(405, 43);
            this.btnTransactionHistory.TabIndex = 3;
            this.btnTransactionHistory.Text = "Transaction History";
            this.btnTransactionHistory.UseVisualStyleBackColor = false;
            this.btnTransactionHistory.Click += new System.EventHandler(this.btnRecordTransaction_Click);
            // 
            // pnlTreansactionsHeader
            // 
            this.pnlTreansactionsHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(28)))), ((int)(((byte)(47)))));
            this.pnlTreansactionsHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTreansactionsHeader.Controls.Add(this.ptbIcon);
            this.pnlTreansactionsHeader.Controls.Add(this.lblMakeTransactionHeader);
            this.pnlTreansactionsHeader.Location = new System.Drawing.Point(238, 12);
            this.pnlTreansactionsHeader.Name = "pnlTreansactionsHeader";
            this.pnlTreansactionsHeader.Size = new System.Drawing.Size(1329, 56);
            this.pnlTreansactionsHeader.TabIndex = 4;
            // 
            // ptbIcon
            // 
            this.ptbIcon.Image = global::Trust_ID_transaction_PArt.Properties.Resources.Transaction_free_icons_designed_by_Magnific;
            this.ptbIcon.Location = new System.Drawing.Point(225, 11);
            this.ptbIcon.Name = "ptbIcon";
            this.ptbIcon.Size = new System.Drawing.Size(30, 28);
            this.ptbIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbIcon.TabIndex = 1;
            this.ptbIcon.TabStop = false;
            // 
            // lblMakeTransactionHeader
            // 
            this.lblMakeTransactionHeader.AutoSize = true;
            this.lblMakeTransactionHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMakeTransactionHeader.ForeColor = System.Drawing.Color.White;
            this.lblMakeTransactionHeader.Location = new System.Drawing.Point(17, 11);
            this.lblMakeTransactionHeader.Name = "lblMakeTransactionHeader";
            this.lblMakeTransactionHeader.Size = new System.Drawing.Size(202, 28);
            this.lblMakeTransactionHeader.TabIndex = 0;
            this.lblMakeTransactionHeader.Text = "Make Transaction(s)";
            // 
            // txtDisplayEnteredInfor
            // 
            this.txtDisplayEnteredInfor.Location = new System.Drawing.Point(1298, 74);
            this.txtDisplayEnteredInfor.Multiline = true;
            this.txtDisplayEnteredInfor.Name = "txtDisplayEnteredInfor";
            this.txtDisplayEnteredInfor.Size = new System.Drawing.Size(269, 497);
            this.txtDisplayEnteredInfor.TabIndex = 5;
            // 
            // frmTransactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(13)))), ((int)(((byte)(27)))));
            this.ClientSize = new System.Drawing.Size(1579, 614);
            this.Controls.Add(this.txtDisplayEnteredInfor);
            this.Controls.Add(this.pnlTreansactionsHeader);
            this.Controls.Add(this.btnTransactionHistory);
            this.Controls.Add(this.pnlSelectedCounterParty);
            this.Controls.Add(this.pnlCounterParty);
            this.Controls.Add(this.pnlContent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTransactions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transactions (TrustID)";
            this.Load += new System.EventHandler(this.frmTransactions_Load);
            this.pnlContent.ResumeLayout(false);
            this.pnlContent.PerformLayout();
            this.pnlCounterParty.ResumeLayout(false);
            this.pnlCounterParty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erpValidatior)).EndInit();
            this.pnlSelectedCounterParty.ResumeLayout(false);
            this.pnlSelectedCounterParty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbSelectedParty)).EndInit();
            this.pnlTreansactionsHeader.ResumeLayout(false);
            this.pnlTreansactionsHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlContent;
        private System.Windows.Forms.Label lblTrustName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlCounterParty;
        private System.Windows.Forms.Label lblTranasactionType;
        private System.Windows.Forms.Label lblDateOfExecution;
        private System.Windows.Forms.Label lblTransactionType;
        private System.Windows.Forms.ComboBox cmbTransactionType;
        private System.Windows.Forms.DateTimePicker dtpExecution;
        private System.Windows.Forms.Label lblCounterPartyLookup;
        private System.Windows.Forms.Label lblRewards;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtCounterSearch;
        private System.Windows.Forms.TextBox txtReward;
        private System.Windows.Forms.ErrorProvider erpValidatior;
        private System.Windows.Forms.Button btnEnterAmount;
        private System.Windows.Forms.Button btnSubmittDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblCompleteDescription;
        private System.Windows.Forms.Label lblDisplayDescription;
        private System.Windows.Forms.Panel pnlSelectedCounterParty;
        private System.Windows.Forms.Label lblSelectedCounterParty;
        private System.Windows.Forms.PictureBox ptbSelectedParty;
        private System.Windows.Forms.Label lblSelectedUser;
        private System.Windows.Forms.Label lblSelectedUserJobtitle;
        private System.Windows.Forms.Panel pnlLine1;
        private System.Windows.Forms.Label lblPartyScore;
        private System.Windows.Forms.Panel pnlPartyScore;
        private System.Windows.Forms.Button btnTransactionHistory;
        private System.Windows.Forms.Button btnReviews;
        private System.Windows.Forms.Button btnClearInfo;
        private System.Windows.Forms.Panel pnlTreansactionsHeader;
        private System.Windows.Forms.Label lblMakeTransactionHeader;
        private System.Windows.Forms.PictureBox ptbIcon;
        private System.Windows.Forms.Button btnSubmittInformation;
        private System.Windows.Forms.TextBox txtDisplayEnteredInfor;
    }
}

