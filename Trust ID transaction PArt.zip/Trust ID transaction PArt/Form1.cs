﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trust_ID_transaction_PArt
{
    public partial class frmTransactions : Form
    {
        public frmTransactions()
        {
            InitializeComponent();
        }

        private void frmTransactions_Load(object sender, EventArgs e)
        {
            MakeRound(pnlCounterParty, 25);

            cmbTransactionType.Items.Add("Consultant Agreement");
            cmbTransactionType.Items.Add("Non-disclosure Agreement");
            cmbTransactionType.Items.Add("Partnership Agreement");
            cmbTransactionType.Items.Add("Consulting Agreement");
            cmbTransactionType.Items.Add("Loan Agreement");
            cmbTransactionType.Items.Add("Employment Agreement");
            cmbTransactionType.Items.Add("Service Agreement");

            cmbTransactionType.SelectedIndex = -1;

        }

        private void MakeRound(Control control, int radius)
        {
            GraphicsPath path = new GraphicsPath();

            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(control.Width - radius, 0, radius, radius, 270
                , 90);

            path.AddArc(control.Width - radius, control.Height - radius
                , radius, radius, 0, 90);

            path.AddArc(0, control.Height - radius, radius, radius, 90, 90);

            path.CloseAllFigures();

            control.Region = new Region(path);
        }

        private void cmbTransactionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            string userSelectedType = cmbTransactionType.SelectedItem.ToString();

            MessageBox.Show($"You have selected {userSelectedType}");
        }

        private void dtpExecution_ValueChanged(object sender, EventArgs e)
        {
            DateTime selectedDate = dtpExecution.Value;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchName = txtCounterSearch.Text;

            if (string.IsNullOrWhiteSpace(searchName))
            {
                erpValidatior.SetError(txtCounterSearch, "Enter a party / individual to search for");
            }
            else if (searchName != null)
            {
                MessageBox.Show($"Customer found : {searchName}");
            }
            else
            {
                MessageBox.Show($"Customer not found");
            }
        }

        private void btnEnterAmount_Click(object sender, EventArgs e)
        {
            int userInput;
            string userReward = txtReward.Text;
            erpValidatior.Clear();

            if (string.IsNullOrWhiteSpace(userReward))
            {
                erpValidatior.SetError(txtReward, "Enter the amount");
            }

            if (int.TryParse(txtReward.Text, out userInput))
            {
                MessageBox.Show($"Amount accepted : {userInput}");
            }
            else
            {
                erpValidatior.SetError(txtReward, "Must contain numbers only");
            }
        }

        private void btnSubmittDescription_Click(object sender, EventArgs e)
        {

            string userDescription = txtDescription.Text;

            if (string.IsNullOrWhiteSpace(userDescription))
            {
                erpValidatior.SetError(txtDescription, "Did not enter any description");
            }

            lblDisplayDescription.Text = txtDescription.Text;
        }

        private void pnlPartyScore_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            using (Pen pen = new Pen(Color.FromArgb(0, 235, 130), 9))
            {
                Rectangle colour = new Rectangle(8, 8, 84, 84);
                graphics.DrawArc(pen, colour, -90, 360);
            }
        }

        private void btnRecordTransaction_Click(object sender, EventArgs e)
        {
            frmRecordTransaction form2RecordTransaction = new frmRecordTransaction();
            form2RecordTransaction.Show();
            this.Hide();
        }

        private void btnClearInfo_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to clear all information entered?",
                "CLEAR " , MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                cmbTransactionType.SelectedIndex = -1;
                txtCounterSearch.Clear();
                txtReward.Clear();
                txtDescription.Clear();
            }
            else
            {
                return;
            }
        }

        private void btnReviews_Click(object sender, EventArgs e)
        {
            frmReviews form2Reviews = new frmReviews();
            form2Reviews.Show();
            this.Hide();
        }

        private void btnSubmittInformation_Click(object sender, EventArgs e)
        {
            Transactions userTransaction = new Transactions();

            string transactionType = cmbTransactionType.Text;
            DateTime date_Of_Execution = dtpExecution.Value.Date;
            string userDescription = txtDescription.Text;
            string userPartyLookup = txtCounterSearch.Text;
            decimal user_amount = Convert.ToDecimal(txtReward.Text);

            string reference = transactionType.Substring(0, 1).ToUpper()
              + "-" + date_Of_Execution.ToString("ddMM")
              + "-" + user_amount.ToString().Substring(0, 2);

            MessageBox.Show("Transaction Created Successfully");

            txtDisplayEnteredInfor.Text =
               "Transaction ID: " + reference + Environment.NewLine +
               "Transaction Type: " + transactionType + Environment.NewLine +
               "Date Of Execution: " + date_Of_Execution + Environment.NewLine +
               "Amount: R" + user_amount + Environment.NewLine +
               "Sending To: " + userPartyLookup + Environment.NewLine +
               "Description: " + userDescription + Environment.NewLine;


        }
    }
}
