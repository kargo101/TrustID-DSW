﻿namespace Trust_ID_transaction_PArt
{
    partial class frmRecordTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTrustID2 = new System.Windows.Forms.Label();
            this.pnlTransactionHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSubTitle = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtTopSearch = new System.Windows.Forms.TextBox();
            this.pnlVolLogged = new System.Windows.Forms.Panel();
            this.lblLogged = new System.Windows.Forms.Label();
            this.pnlVerifiedContracts = new System.Windows.Forms.Panel();
            this.lblVerifiedPayments = new System.Windows.Forms.Label();
            this.pnlPendingPayments = new System.Windows.Forms.Panel();
            this.lblPendingPayments = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmbTransactions = new System.Windows.Forms.ComboBox();
            this.dtvTransactions = new System.Windows.Forms.DataGridView();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CounterParty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TrustImpact = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnMakeTransaction = new System.Windows.Forms.Button();
            this.erpValidator = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnReviews = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.pnlTransactionHeader.SuspendLayout();
            this.pnlVolLogged.SuspendLayout();
            this.pnlVerifiedContracts.SuspendLayout();
            this.pnlPendingPayments.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtvTransactions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpValidator)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(25)))), ((int)(((byte)(43)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblTrustID2);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(261, 661);
            this.panel1.TabIndex = 0;
            // 
            // lblTrustID2
            // 
            this.lblTrustID2.AutoSize = true;
            this.lblTrustID2.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrustID2.ForeColor = System.Drawing.Color.Transparent;
            this.lblTrustID2.Location = new System.Drawing.Point(37, 18);
            this.lblTrustID2.Name = "lblTrustID2";
            this.lblTrustID2.Size = new System.Drawing.Size(141, 45);
            this.lblTrustID2.TabIndex = 0;
            this.lblTrustID2.Text = "Trust ID";
            // 
            // pnlTransactionHeader
            // 
            this.pnlTransactionHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(24)))), ((int)(((byte)(42)))));
            this.pnlTransactionHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTransactionHeader.Controls.Add(this.lblTitle);
            this.pnlTransactionHeader.Controls.Add(this.lblSubTitle);
            this.pnlTransactionHeader.Location = new System.Drawing.Point(285, 12);
            this.pnlTransactionHeader.Name = "pnlTransactionHeader";
            this.pnlTransactionHeader.Size = new System.Drawing.Size(943, 90);
            this.pnlTransactionHeader.TabIndex = 1;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(25, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(303, 38);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Transaction(s) History";
            // 
            // lblSubTitle
            // 
            this.lblSubTitle.AutoSize = true;
            this.lblSubTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(150)))), ((int)(((byte)(170)))));
            this.lblSubTitle.Location = new System.Drawing.Point(28, 46);
            this.lblSubTitle.Name = "lblSubTitle";
            this.lblSubTitle.Size = new System.Drawing.Size(532, 40);
            this.lblSubTitle.TabIndex = 2;
            this.lblSubTitle.Text = "Audit Logged digital contracts, verified payouts, and decentralized agreements\r\n\r" +
    "\n";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Aqua;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.Black;
            this.btnSearch.Location = new System.Drawing.Point(694, 20);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(104, 25);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtTopSearch
            // 
            this.txtTopSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(15)))), ((int)(((byte)(29)))));
            this.txtTopSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTopSearch.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTopSearch.ForeColor = System.Drawing.Color.White;
            this.txtTopSearch.Location = new System.Drawing.Point(24, 20);
            this.txtTopSearch.Multiline = true;
            this.txtTopSearch.Name = "txtTopSearch";
            this.txtTopSearch.Size = new System.Drawing.Size(651, 25);
            this.txtTopSearch.TabIndex = 3;
            // 
            // pnlVolLogged
            // 
            this.pnlVolLogged.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(26)))), ((int)(((byte)(45)))));
            this.pnlVolLogged.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlVolLogged.Controls.Add(this.lblLogged);
            this.pnlVolLogged.Location = new System.Drawing.Point(285, 124);
            this.pnlVolLogged.Name = "pnlVolLogged";
            this.pnlVolLogged.Size = new System.Drawing.Size(300, 100);
            this.pnlVolLogged.TabIndex = 2;
            // 
            // lblLogged
            // 
            this.lblLogged.AutoSize = true;
            this.lblLogged.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogged.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(150)))), ((int)(((byte)(170)))));
            this.lblLogged.Location = new System.Drawing.Point(21, 9);
            this.lblLogged.Name = "lblLogged";
            this.lblLogged.Size = new System.Drawing.Size(113, 17);
            this.lblLogged.TabIndex = 3;
            this.lblLogged.Text = "Total Vol Logged";
            // 
            // pnlVerifiedContracts
            // 
            this.pnlVerifiedContracts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(26)))), ((int)(((byte)(45)))));
            this.pnlVerifiedContracts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlVerifiedContracts.Controls.Add(this.lblVerifiedPayments);
            this.pnlVerifiedContracts.Location = new System.Drawing.Point(607, 124);
            this.pnlVerifiedContracts.Name = "pnlVerifiedContracts";
            this.pnlVerifiedContracts.Size = new System.Drawing.Size(300, 100);
            this.pnlVerifiedContracts.TabIndex = 3;
            // 
            // lblVerifiedPayments
            // 
            this.lblVerifiedPayments.AutoSize = true;
            this.lblVerifiedPayments.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVerifiedPayments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(150)))), ((int)(((byte)(170)))));
            this.lblVerifiedPayments.Location = new System.Drawing.Point(25, 9);
            this.lblVerifiedPayments.Name = "lblVerifiedPayments";
            this.lblVerifiedPayments.Size = new System.Drawing.Size(120, 17);
            this.lblVerifiedPayments.TabIndex = 3;
            this.lblVerifiedPayments.Text = "Verified Payments";
            // 
            // pnlPendingPayments
            // 
            this.pnlPendingPayments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(26)))), ((int)(((byte)(45)))));
            this.pnlPendingPayments.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlPendingPayments.Controls.Add(this.lblPendingPayments);
            this.pnlPendingPayments.Location = new System.Drawing.Point(929, 124);
            this.pnlPendingPayments.Name = "pnlPendingPayments";
            this.pnlPendingPayments.Size = new System.Drawing.Size(300, 100);
            this.pnlPendingPayments.TabIndex = 4;
            // 
            // lblPendingPayments
            // 
            this.lblPendingPayments.AutoSize = true;
            this.lblPendingPayments.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPendingPayments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(150)))), ((int)(((byte)(170)))));
            this.lblPendingPayments.Location = new System.Drawing.Point(17, 9);
            this.lblPendingPayments.Name = "lblPendingPayments";
            this.lblPendingPayments.Size = new System.Drawing.Size(123, 17);
            this.lblPendingPayments.TabIndex = 3;
            this.lblPendingPayments.Text = "Pending Payments";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(26)))), ((int)(((byte)(45)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.btnSearch);
            this.panel2.Controls.Add(this.txtTopSearch);
            this.panel2.Controls.Add(this.cmbTransactions);
            this.panel2.Location = new System.Drawing.Point(285, 245);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(943, 65);
            this.panel2.TabIndex = 5;
            // 
            // cmbTransactions
            // 
            this.cmbTransactions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(15)))), ((int)(((byte)(29)))));
            this.cmbTransactions.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbTransactions.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTransactions.ForeColor = System.Drawing.Color.White;
            this.cmbTransactions.FormattingEnabled = true;
            this.cmbTransactions.Location = new System.Drawing.Point(815, 20);
            this.cmbTransactions.Name = "cmbTransactions";
            this.cmbTransactions.Size = new System.Drawing.Size(121, 25);
            this.cmbTransactions.TabIndex = 0;
           
            // 
            // dtvTransactions
            // 
            this.dtvTransactions.AllowUserToAddRows = false;
            this.dtvTransactions.AllowUserToDeleteRows = false;
            this.dtvTransactions.AllowUserToResizeColumns = false;
            this.dtvTransactions.AllowUserToResizeRows = false;
            this.dtvTransactions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtvTransactions.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(24)))), ((int)(((byte)(42)))));
            this.dtvTransactions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(15)))), ((int)(((byte)(29)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(169)))), ((int)(((byte)(188)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtvTransactions.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtvTransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtvTransactions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date,
            this.CounterParty,
            this.ContractType,
            this.Amount,
            this.TrustImpact});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(24)))), ((int)(((byte)(42)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtvTransactions.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtvTransactions.EnableHeadersVisualStyles = false;
            this.dtvTransactions.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.dtvTransactions.Location = new System.Drawing.Point(285, 329);
            this.dtvTransactions.MultiSelect = false;
            this.dtvTransactions.Name = "dtvTransactions";
            this.dtvTransactions.RowHeadersVisible = false;
            this.dtvTransactions.RowHeadersWidth = 51;
            this.dtvTransactions.RowTemplate.Height = 24;
            this.dtvTransactions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtvTransactions.Size = new System.Drawing.Size(943, 276);
            this.dtvTransactions.TabIndex = 6;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.MinimumWidth = 6;
            this.Date.Name = "Date";
            // 
            // CounterParty
            // 
            this.CounterParty.HeaderText = "Counter Party";
            this.CounterParty.MinimumWidth = 6;
            this.CounterParty.Name = "CounterParty";
            // 
            // ContractType
            // 
            this.ContractType.HeaderText = "Contract Type";
            this.ContractType.MinimumWidth = 6;
            this.ContractType.Name = "ContractType";
            // 
            // Amount
            // 
            this.Amount.HeaderText = "Amount";
            this.Amount.MinimumWidth = 6;
            this.Amount.Name = "Amount";
            // 
            // TrustImpact
            // 
            this.TrustImpact.HeaderText = "Trust Impact";
            this.TrustImpact.MinimumWidth = 6;
            this.TrustImpact.Name = "TrustImpact";
            // 
            // btnMakeTransaction
            // 
            this.btnMakeTransaction.BackColor = System.Drawing.Color.Lime;
            this.btnMakeTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMakeTransaction.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMakeTransaction.ForeColor = System.Drawing.Color.Black;
            this.btnMakeTransaction.Location = new System.Drawing.Point(981, 612);
            this.btnMakeTransaction.Name = "btnMakeTransaction";
            this.btnMakeTransaction.Size = new System.Drawing.Size(247, 41);
            this.btnMakeTransaction.TabIndex = 7;
            this.btnMakeTransaction.Text = "Make Transaction(s)";
            this.btnMakeTransaction.UseVisualStyleBackColor = false;
            this.btnMakeTransaction.Click += new System.EventHandler(this.btnMakeTransaction_Click);
            // 
            // erpValidator
            // 
            this.erpValidator.ContainerControl = this;
            // 
            // btnReviews
            // 
            this.btnReviews.BackColor = System.Drawing.Color.Cyan;
            this.btnReviews.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReviews.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviews.ForeColor = System.Drawing.Color.Black;
            this.btnReviews.Location = new System.Drawing.Point(728, 611);
            this.btnReviews.Name = "btnReviews";
            this.btnReviews.Size = new System.Drawing.Size(247, 41);
            this.btnReviews.TabIndex = 8;
            this.btnReviews.Text = "Show Review(s)";
            this.btnReviews.UseVisualStyleBackColor = false;
            this.btnReviews.Click += new System.EventHandler(this.btnReviews_Click);
            // 
            // frmRecordTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(13)))), ((int)(((byte)(27)))));
            this.ClientSize = new System.Drawing.Size(1240, 665);
            this.Controls.Add(this.btnReviews);
            this.Controls.Add(this.btnMakeTransaction);
            this.Controls.Add(this.dtvTransactions);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlPendingPayments);
            this.Controls.Add(this.pnlVerifiedContracts);
            this.Controls.Add(this.pnlVolLogged);
            this.Controls.Add(this.pnlTransactionHeader);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmRecordTransaction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Record_Transaction";
            this.Load += new System.EventHandler(this.frmRecordTransaction_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlTransactionHeader.ResumeLayout(false);
            this.pnlTransactionHeader.PerformLayout();
            this.pnlVolLogged.ResumeLayout(false);
            this.pnlVolLogged.PerformLayout();
            this.pnlVerifiedContracts.ResumeLayout(false);
            this.pnlVerifiedContracts.PerformLayout();
            this.pnlPendingPayments.ResumeLayout(false);
            this.pnlPendingPayments.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtvTransactions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpValidator)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTrustID2;
        private System.Windows.Forms.Panel pnlTransactionHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSubTitle;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtTopSearch;
        private System.Windows.Forms.Panel pnlVolLogged;
        private System.Windows.Forms.Label lblLogged;
        private System.Windows.Forms.Panel pnlVerifiedContracts;
        private System.Windows.Forms.Label lblVerifiedPayments;
        private System.Windows.Forms.Panel pnlPendingPayments;
        private System.Windows.Forms.Label lblPendingPayments;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cmbTransactions;
        private System.Windows.Forms.DataGridView dtvTransactions;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn CounterParty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn TrustImpact;
        private System.Windows.Forms.Button btnMakeTransaction;
        private System.Windows.Forms.ErrorProvider erpValidator;
        private System.Windows.Forms.Button btnReviews;
    }
}