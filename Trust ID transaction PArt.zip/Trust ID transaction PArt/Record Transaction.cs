﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Trust_ID_transaction_PArt
{
    public partial class frmRecordTransaction : Form
    {
        public frmRecordTransaction()
        {
            InitializeComponent();
        }
        private void frmRecordTransaction_Load(object sender, EventArgs e)
        {
            cmbTransactions.Items.Add("Pending Transactions");
            cmbTransactions.Items.Add("Complete Transactions");
            cmbTransactions.Items.Add("Re-Jected Transactions");
            cmbTransactions.SelectedIndex = -1;
        }

        private void btnMakeTransaction_Click(object sender, EventArgs e)
        {
            frmTransactions form1Transactions = new frmTransactions();
            form1Transactions.Show();
            this.Hide();
           
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTransaction = txtTopSearch.Text;
            erpValidator.Clear();
            bool validation = false;

            if (string.IsNullOrWhiteSpace(searchTransaction))
            {
                erpValidator.SetError(txtTopSearch, "Enter a transaction to search for.");
                validation = false;
            }

            if (validation == true)
            {

            }
        }

        private void btnReviews_Click(object sender, EventArgs e)
        {
            frmReviews form3Reviews = new frmReviews();
            form3Reviews.Show();
            this.Hide();
        }

    }
}
