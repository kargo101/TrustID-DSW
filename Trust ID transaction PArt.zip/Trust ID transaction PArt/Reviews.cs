﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trust_ID_transaction_PArt
{
    public partial class frmReviews : Form
    {
        public frmReviews()
        {
            InitializeComponent();
        }
       
    }
}
