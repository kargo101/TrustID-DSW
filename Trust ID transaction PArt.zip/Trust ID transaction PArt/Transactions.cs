﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trust_ID_transaction_PArt
{
    internal class Transactions
    {

        private string transactionID;
        private string transactionType;
        private DateTime dateOfExecution;
        private string description;
        private string counterPartySearch;
        private decimal userAmount;
       
        public void TransactionID(string transaction_ID, string transaction_Type
            , DateTime dateOf_Execution, string Description, string partySearch,
            decimal user_Amount)
        {
            this.transactionID = transaction_ID;
            this.transactionType = transaction_Type;
            this.dateOfExecution = dateOf_Execution;
            this.description = Description;
            this.counterPartySearch = partySearch;
            this.userAmount = user_Amount;
        }

        public string TransactionType(string transactIonType) 
        {
             return transactionType;
        }

        public string TransactionID(string transaction_ID)
        {
            return transactionID; 
        }

        public string UserDescription(string descriPtion)
        {
            return description;
        }

        public DateTime DateOfExecution()
        {
            return dateOfExecution;
        }
         public string CounterPartySearch()
         {
            return counterPartySearch; 
         }

        public decimal UserAmount()
        {
            return userAmount;
        }

        //public string TransactionID( string transaction_Type, decimal user_Entered_Amount,
        //    DateTime userDateOf_Execution)
        //{
        //    string reference = transaction_Type.Substring(0, 1).ToUpper()
        //        + "-" + userDateOf_Execution.ToString("ddMM")
        //        + "-" + user_Entered_Amount.ToString().Substring(0, 2);

        //    return reference;
        //}
    }
}
