# TrustID – Verification Requests Module (Eugene's Section)

A standalone C# Windows Forms project for the **Verification Requests**
part of the TrustID group project, styled to match the dark TrustID
dashboard theme the group is using.

## 1. How to open it in Visual Studio

1. Unzip the folder anywhere on your PC.
2. Double-click `TrustID.Verification.sln`. Visual Studio opens the solution.
3. Make sure the **".NET desktop development"** workload is installed
   (Visual Studio Installer → Modify → tick that workload). This project
   targets **.NET 8**, which ships with current Visual Studio 2022.
4. Press **F5** to build and run it.

## 2. How to see the form design WITHOUT running it

You don't need to run the program to see the layout:

1. In **Solution Explorer**, open the `Forms` folder.
2. Double-click `MainForm.cs`. Because it's a Form (and has a matching
   `MainForm.Designer.cs`), Visual Studio automatically opens it in the
   **Designer view** — the actual drag-and-drop visual view — instead of
   the code.
3. If it opens showing code instead, right-click `MainForm.cs` in Solution
   Explorer and choose **View Designer** (or press **Shift+F7**).
4. To go back to the code at any time, right-click and choose **View Code**
   (or press **F7**).

You can click on any control in that Designer view and see/change its
properties (colour, position, text, etc.) in the **Properties** window,
exactly like a form you built by dragging controls from the toolbox.

## 3. Adding a new button or textbox yourself

1. Open `MainForm.cs` in Design view (see step 2 above).
2. Open the **Toolbox** if it isn't already open: **View → Toolbox** (or Ctrl+Alt+X).
3. Drag a control (e.g. `Button` or `TextBox`) from the Toolbox onto the form.
   - Drop it **inside the card/panel** you want it to belong to (e.g. drop it
     inside the white "Your Information" box, not out in empty space),
     otherwise it'll attach to the wrong container.
4. With the new control selected, press **F4** to open the **Properties**
   window and set its `Name`, `Text`, `Location`, `Size`, `BackColor`, etc.
5. Double-click the control to generate a click event handler in `MainForm.cs`
   where you can write what happens when it's used.

## 4. Rounded ("curvy") buttons

Windows Forms buttons don't have a built-in "corner radius" setting, so the
usual trick is to clip the button into a rounded shape using a `Region`.
That's exactly what `Controls/RoundedButton.cs` does — it's a normal
`Button` that redraws its own outline as a rounded rectangle. The
"Submit Verification Request" button and both "Choose File..." buttons use
it already (`CornerRadius` property controls how round the corners are).

To make any other button rounded, just use `RoundedButton` instead of
`Button` when creating it, e.g.:
```csharp
var btn = new RoundedButton();
btn.CornerRadius = 10;
```

## 5. Project structure

```
TrustID.Verification.sln
TrustID.Verification/
 ├─ TrustID.Verification.csproj
 ├─ Program.cs                      -> application entry point (Main method)
 ├─ Models/
 │   └─ VerificationRequest.cs      -> data shape for a verification request
 ├─ Controls/
 │   └─ RoundedCardPanel.cs         -> small reusable rounded "card" panel
 ├─ Forms/
 │   ├─ MainForm.cs                 -> logic: file dialogs, validation, submit
 │   └─ MainForm.Designer.cs        -> UI layout (controls, colours, positions)
 └─ Resources/
     └─ app_icon.ico                -> TrustID app icon (built into the .exe)
```

## 6. What this screen does

- **Verification request screen** – the whole `MainForm`.
- **Verification information submission** – Full Name, Email, and
  Qualification are typed in by the user (nothing is hardcoded), plus the
  two "Choose File..." buttons for the Identity Document and Qualification
  Certificate.
- **No contact verification** – TrustID does not have a contact verification
  step, so only **Identity Verification** and **Qualification Verification**
  are shown.
- **Storing verification requests** – on submit, a `VerificationRequest`
  object is created from the values on the form and added to the
  "My Verification Requests" grid (in memory for now — this is the UI phase).
- **Verification request status** – before submitting anything, both
  statuses show "Not Submitted". After submitting, they change to "Pending".
  The screen never shows "Verified" by itself — that label is only ever set
  by an administrator elsewhere in the system (see `SetStatusLabel` in
  `MainForm.cs`, which is ready to display "Verified"/"Rejected" once that
  data exists, but nothing in this file sets those values itself).
- **Supporting/shared UI** – the dark sidebar with the TrustID logo and
  navigation matches the shell used across the other screens. Only
  "Verification" is enabled here since the rest of those sections belong to
  teammates.

## 7. Naming conventions

All controls follow the Hungarian-style prefixes from `C3_WinForms_Prefix.pdf`
(`btn`, `txt`, `lbl`, `dgv`, `pnl`, `pic`), so it's easy to read next to that
reference sheet.

## 8. Connecting this to your group's GitHub repository

Since your group already created a shared repo, here's how to add your work
to it using Visual Studio (or plain Git commands — both shown).

### Option A — using Visual Studio's Git tools

1. Open Visual Studio, but **don't** open this project yet.
2. Go to **File → Clone Repository**, paste your group's repo URL, choose a
   folder on your PC, and click **Clone**. This downloads the group project.
3. In **Team Explorer / Git Changes**, create your own branch:
   - Click the branch name in the bottom-right corner → **New Branch**.
   - Name it `eugene-verification` (matching the naming your group agreed on).
4. Copy the following folders/files from this zip into the cloned repo
   (ask your group where they want individual sections placed — usually
   inside a shared solution, or in a folder per person for now):
   - `Forms/MainForm.cs`, `Forms/MainForm.Designer.cs`
   - `Models/VerificationRequest.cs`
   - `Controls/RoundedCardPanel.cs`
   - `Resources/app_icon.ico`
5. In **Solution Explorer**, right-click the project → **Add → Existing Item**
   and add the copied files if they don't appear automatically.
6. Build the project (Ctrl+Shift+B) to make sure it still compiles.
7. In **Git Changes**, write a commit message (e.g. "Add verification
   requests screen") and click **Commit All**, then **Push**.
8. On GitHub, open a **Pull Request** from `eugene-verification` into `main`
   (or whichever branch your group merges into) so the team can review it
   before merging — this matches the workflow in your group's PDF:
   `Code → Commit → Push → Test → Pull Request → Review → Merge`.

### Option B — using plain Git commands

```bash
# 1. Clone the repo (only the first time)
git clone https://github.com/your-group/your-repo.git
cd your-repo

# 2. Create and switch to your own branch
git checkout -b eugene-verification

# 3. Copy this project's files into the repo folder, then:
git add .
git commit -m "Add verification requests screen"
git push -u origin eugene-verification
```

Then open a Pull Request on GitHub from `eugene-verification` into the
main branch.

### A .gitignore tip

If your group's repo doesn't already have one, ask them to add a
`.gitignore` with at least this in it, so build files don't get committed:

```
bin/
obj/
.vs/
```

## 9. Undoing mistakes / rolling back (Git safety net)

Everyone breaks something eventually — here's how to safely undo it.

**Undo changes you haven't committed yet:**
Open **Git Changes** (View → Git Changes). Right-click the file → **Discard
Changes**. This throws away your edits and restores the last committed
version.

**See the history of a file:**
Right-click the file in Solution Explorer → **View History**. This shows
every commit that touched it, who made it, and when.

**Go back to an older version safely (recommended):**
In that history view, right-click an older commit → **Revert**. This creates
a **new** commit that undoes those changes, without deleting history. Safe
to do even on a shared branch, since nobody's work gets erased.

**What to avoid:** don't use `git reset --hard` or force-push on `main` or
any branch teammates are also using — that rewrites history and can wipe
out other people's commits. Only use it on your own branch, on commits you
haven't pushed yet.

**If a bad Pull Request already got merged into `main`:** open that PR on
GitHub and click **Revert** — GitHub creates a new PR that undoes exactly
that merge, cleanly, without touching anything else.

## 10. Adding Supabase later (for real backend storage)

This project currently stores requests in memory only (they disappear when
you close the app). When you're ready to connect a real backend:

1. Go to [supabase.com](https://supabase.com), sign in, and create a new
   project (pick a name, password, and region).
2. In the Supabase dashboard, go to **Table Editor** and create a table,
   e.g. `verification_requests`, with columns like:
   `id` (int8, auto), `full_name` (text), `email` (text),
   `qualification` (text), `identity_status` (text), `qualification_status` (text).
3. Go to **Project Settings → API** and copy your **Project URL** and
   **anon public key**.
4. In Visual Studio: right-click the project in Solution Explorer →
   **Manage NuGet Packages** → **Browse** → search for **`Supabase`**
   (published by supabase-community) → **Install**.
5. Create a new file, e.g. `Services/SupabaseService.cs`, with something
   like this (this is a starting point — check the current docs at
   supabase.com/docs/reference/csharp for anything that's changed):

```csharp
using Supabase;
using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

// This describes one row in your "verification_requests" table.
[Table("verification_requests")]
public class VerificationRequestRow : BaseModel
{
    [PrimaryKey("id", false)]
    public int Id { get; set; }

    [Column("full_name")]
    public string FullName { get; set; }

    [Column("email")]
    public string Email { get; set; }

    [Column("qualification")]
    public string Qualification { get; set; }

    [Column("identity_status")]
    public string IdentityStatus { get; set; }

    [Column("qualification_status")]
    public string QualificationStatus { get; set; }
}

public class SupabaseService
{
    private readonly Client client;

    public SupabaseService()
    {
        string url = "https://YOUR-PROJECT.supabase.co";
        string key = "YOUR-ANON-PUBLIC-KEY";
        client = new Client(url, key, new SupabaseOptions { AutoConnectRealtime = false });
    }

    public async Task ConnectAsync()
    {
        await client.InitializeAsync();
    }

    public async Task SaveRequestAsync(VerificationRequestRow row)
    {
        await client.From<VerificationRequestRow>().Insert(row);
    }
}
```

6. Because Visual Studio's `Main()` normally isn't `async`, call
   `ConnectAsync()` once when the form loads, e.g. in the `MainForm`
   constructor using `.GetAwaiter().GetResult()`, or make `Main` an
   `async Task` method.
7. In `btnSubmit_Click`, alongside adding the row to the grid, call
   `await supabaseService.SaveRequestAsync(row);` so it's saved for real.

Never commit your real Supabase key to GitHub in plain text — ask your
team how they want to manage secrets (a config file that's in `.gitignore`
is a common first-year-friendly approach).

## 11. Next steps (functionality phase, not done yet)

- Replace the in-memory list/grid with real shared storage (e.g. a database
  or shared file) so the Admin Dashboard can actually see submitted requests
  and change their status to "Verified" or "Rejected".
- Connect Full Name/Email to the real logged-in user once Registration &
  Login is merged in, instead of the user typing it in manually every time.
- Copy the chosen document files into a permanent app folder instead of just
  keeping the original file path, since the source file could be moved later.
