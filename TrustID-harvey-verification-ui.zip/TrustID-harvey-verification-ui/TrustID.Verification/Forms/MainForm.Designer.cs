using System.Drawing;
using System.Windows.Forms;
using TrustID.Verification.Controls;

namespace TrustID.Verification.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

       
        private Panel pnlSidebar;
        private Label lblBrandIcon;
        private Label lblBrand;
        private Label lblBrandSub;
        private Button btnNavDashboard;
        private Button btnNavProfile;
        private Button btnNavSearchUsers;
        private Button btnNavTransactions;
        private Button btnNavReviews;
        private Button btnNavVerification;
        private Button btnNavSettings;
        private Panel pnlUserFooter;
        private Panel pnlAvatar;
        private Label lblAvatarInitials;
        private Label lblUserName;
        private Label lblUserStatus;

        
        private Panel pnlContent;
        private Panel pnlContentScroll;
        private Label lblSectionTag;
        private Label lblTitle;
        private Label lblSubtitle;

        private RoundedCardPanel cardYourInfo;
        private Label lblYourInfoHeader;
        private Label lblFullNameCaption;
        private TextBox txtFullName;
        private Label lblEmailCaption;
        private TextBox txtEmail;
        private Label lblQualCaption;
        private TextBox txtQualification;

        private RoundedCardPanel cardStatus;
        private Label lblStatusHeader;
        private Label lblIdStatusCaption;
        private Label lblIdStatusValue;
        private Label lblQualStatusCaption;
        private Label lblQualStatusValue;
        private Label lblStatusNote;

        private RoundedCardPanel cardDocuments;
        private Label lblDocumentsHeader;
        private Label lblIdDocCaption;
        private RoundedButton btnChooseIdDoc;
        private Label lblIdDocFileName;
        private Label lblQualDocCaption;
        private RoundedButton btnChooseQualDoc;
        private Label lblQualDocFileName;

        private Label lblSubmitHint;
        private RoundedButton btnSubmit;

        private Label lblHistoryTitle;
        private DataGridView dgvHistory;

        
        private readonly Color appBackground = Color.FromArgb(10, 14, 26);      
        private readonly Color sidebarBackground = Color.FromArgb(10, 14, 26);
        private readonly Color cardBackground = Color.FromArgb(19, 26, 44);   
        private readonly Color cardBorder = Color.FromArgb(35, 43, 61);        
        private readonly Color inputBackground = Color.FromArgb(27, 36, 54);    
        private readonly Color accentCyan = Color.FromArgb(34, 211, 238);      
        private readonly Color textPrimary = Color.FromArgb(232, 234, 240);    
        private readonly Color textSecondary = Color.FromArgb(136, 146, 166);  

        
        private readonly Color statusNotSubmittedColor = Color.FromArgb(136, 146, 166);
        private readonly Color statusPendingColor = Color.FromArgb(245, 165, 36);
        private readonly Color statusVerifiedColor = Color.FromArgb(34, 197, 94);
        private readonly Color statusRejectedColor = Color.FromArgb(239, 68, 68);

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

           
            this.SuspendLayout();
            this.Text = "Verification Requests - TrustID Platform (v1.4.2)";
            this.ClientSize = new Size(1150, 780);
            this.MinimumSize = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = this.appBackground;
            this.Font = new Font("Segoe UI", 9F);

           
            this.pnlSidebar = new Panel();
            this.pnlSidebar.Dock = DockStyle.Left;
            this.pnlSidebar.Width = 220;
            this.pnlSidebar.BackColor = this.sidebarBackground;

            this.lblBrandIcon = new Label();
            this.lblBrandIcon.Text = "T";
            this.lblBrandIcon.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblBrandIcon.ForeColor = this.appBackground;
            this.lblBrandIcon.BackColor = this.accentCyan;
            this.lblBrandIcon.TextAlign = ContentAlignment.MiddleCenter;
            this.lblBrandIcon.Location = new Point(20, 20);
            this.lblBrandIcon.Size = new Size(32, 32);

            this.lblBrand = new Label();
            this.lblBrand.Text = "TrustID";
            this.lblBrand.ForeColor = this.textPrimary;
            this.lblBrand.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            this.lblBrand.Location = new Point(62, 18);
            this.lblBrand.AutoSize = true;

            this.lblBrandSub = new Label();
            this.lblBrandSub.Text = "DESKTOP CLIENT";
            this.lblBrandSub.ForeColor = this.textSecondary;
            this.lblBrandSub.Font = new Font("Segoe UI", 7F);
            this.lblBrandSub.Location = new Point(63, 42);
            this.lblBrandSub.AutoSize = true;

            this.btnNavDashboard = CreateNavButton("Dashboard", 90);
            this.btnNavProfile = CreateNavButton("Profile", 130);
            this.btnNavSearchUsers = CreateNavButton("Search Users", 170);
            this.btnNavTransactions = CreateNavButton("Transactions", 210);
            this.btnNavReviews = CreateNavButton("Reviews", 250);
            this.btnNavVerification = CreateNavButton("Verification", 290);
            this.btnNavSettings = CreateNavButton("Settings", 330);

           
            this.btnNavDashboard.Enabled = false;
            this.btnNavProfile.Enabled = false;
            this.btnNavSearchUsers.Enabled = false;
            this.btnNavTransactions.Enabled = false;
            this.btnNavReviews.Enabled = false;
            this.btnNavSettings.Enabled = false;

            this.btnNavDashboard.ForeColor = this.textSecondary;
            this.btnNavProfile.ForeColor = this.textSecondary;
            this.btnNavSearchUsers.ForeColor = this.textSecondary;
            this.btnNavTransactions.ForeColor = this.textSecondary;
            this.btnNavReviews.ForeColor = this.textSecondary;
            this.btnNavSettings.ForeColor = this.textSecondary;

           
            this.btnNavVerification.BackColor = this.cardBackground;
            this.btnNavVerification.ForeColor = this.accentCyan;
            this.btnNavVerification.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);

            this.pnlUserFooter = new Panel();
            this.pnlUserFooter.Dock = DockStyle.Bottom;
            this.pnlUserFooter.Height = 70;
            this.pnlUserFooter.BackColor = this.sidebarBackground;

            this.pnlAvatar = new Panel();
            this.pnlAvatar.Size = new Size(36, 36);
            this.pnlAvatar.Location = new Point(20, 17);
            
            this.pnlAvatar.BackColor = this.sidebarBackground;
            this.pnlAvatar.Paint += new PaintEventHandler(this.pnlAvatar_Paint);

            this.lblAvatarInitials = new Label();
            this.lblAvatarInitials.Text = "EU";
            this.lblAvatarInitials.ForeColor = this.appBackground;
            this.lblAvatarInitials.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblAvatarInitials.Dock = DockStyle.Fill;
            this.lblAvatarInitials.TextAlign = ContentAlignment.MiddleCenter;
            this.lblAvatarInitials.BackColor = Color.Transparent;

            this.lblUserName = new Label();
            this.lblUserName.Text = "Eugene";
            this.lblUserName.ForeColor = this.textPrimary;
            this.lblUserName.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblUserName.Location = new Point(65, 16);
            this.lblUserName.AutoSize = true;

            this.lblUserStatus = new Label();
            this.lblUserStatus.Text = "Verification Module";
            this.lblUserStatus.ForeColor = this.textSecondary;
            this.lblUserStatus.Font = new Font("Segoe UI", 8F);
            this.lblUserStatus.Location = new Point(65, 34);
            this.lblUserStatus.AutoSize = true;

            this.pnlAvatar.Controls.Add(this.lblAvatarInitials);
            this.pnlUserFooter.Controls.Add(this.pnlAvatar);
            this.pnlUserFooter.Controls.Add(this.lblUserName);
            this.pnlUserFooter.Controls.Add(this.lblUserStatus);

            this.pnlSidebar.Controls.Add(this.lblBrandIcon);
            this.pnlSidebar.Controls.Add(this.lblBrand);
            this.pnlSidebar.Controls.Add(this.lblBrandSub);
            this.pnlSidebar.Controls.Add(this.btnNavDashboard);
            this.pnlSidebar.Controls.Add(this.btnNavProfile);
            this.pnlSidebar.Controls.Add(this.btnNavSearchUsers);
            this.pnlSidebar.Controls.Add(this.btnNavTransactions);
            this.pnlSidebar.Controls.Add(this.btnNavReviews);
            this.pnlSidebar.Controls.Add(this.btnNavVerification);
            this.pnlSidebar.Controls.Add(this.btnNavSettings);
            this.pnlSidebar.Controls.Add(this.pnlUserFooter);

            
            this.pnlContent = new Panel();
            this.pnlContent.Dock = DockStyle.Fill;
            this.pnlContent.BackColor = this.appBackground;

            this.pnlContentScroll = new Panel();
            this.pnlContentScroll.Dock = DockStyle.Fill;
            this.pnlContentScroll.AutoScroll = true;
            this.pnlContentScroll.BackColor = this.appBackground;

            this.lblSectionTag = new Label();
            this.lblSectionTag.Text = "  VERIFICATION CENTER  ";
            this.lblSectionTag.ForeColor = this.accentCyan;
            this.lblSectionTag.BackColor = Color.FromArgb(15, 40, 48);
            this.lblSectionTag.Font = new Font("Segoe UI", 7.5F, FontStyle.Bold);
            this.lblSectionTag.Location = new Point(32, 24);
            this.lblSectionTag.AutoSize = true;

            this.lblTitle = new Label();
            this.lblTitle.Text = "Verification Requests";
            this.lblTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            this.lblTitle.ForeColor = this.textPrimary;
            this.lblTitle.Location = new Point(30, 52);
            this.lblTitle.AutoSize = true;

            this.lblSubtitle = new Label();
            this.lblSubtitle.Text = "Submit your documents for identity and qualification verification.";
            this.lblSubtitle.ForeColor = this.textSecondary;
            this.lblSubtitle.Font = new Font("Segoe UI", 9.5F);
            this.lblSubtitle.Location = new Point(31, 90);
            this.lblSubtitle.AutoSize = true;

            
            this.cardYourInfo = new RoundedCardPanel();
            this.cardYourInfo.Location = new Point(30, 128);
            this.cardYourInfo.Size = new Size(460, 210);
            this.cardYourInfo.BackColor = this.cardBackground;
            this.cardYourInfo.BorderColor = this.cardBorder;
            this.cardYourInfo.CornerRadius = 12;

            this.lblYourInfoHeader = CreateCardHeader("Your Information");

            this.lblFullNameCaption = CreateCaptionLabel("Full Name", 18, 54);
            this.txtFullName = CreateInputBox(18, 72, 424);
            this.txtFullName.PlaceholderText = "Enter your full name";

            this.lblEmailCaption = CreateCaptionLabel("Email Address", 18, 108);
            this.txtEmail = CreateInputBox(18, 126, 424);
            this.txtEmail.PlaceholderText = "Enter your email address";

            this.lblQualCaption = CreateCaptionLabel("Qualification", 18, 162);
            this.txtQualification = CreateInputBox(18, 180, 424);
            this.txtQualification.PlaceholderText = "e.g. Diploma in Business Management";

            this.cardYourInfo.Controls.Add(this.lblYourInfoHeader);
            this.cardYourInfo.Controls.Add(this.lblFullNameCaption);
            this.cardYourInfo.Controls.Add(this.txtFullName);
            this.cardYourInfo.Controls.Add(this.lblEmailCaption);
            this.cardYourInfo.Controls.Add(this.txtEmail);
            this.cardYourInfo.Controls.Add(this.lblQualCaption);
            this.cardYourInfo.Controls.Add(this.txtQualification);

            
            this.cardStatus = new RoundedCardPanel();
            this.cardStatus.Location = new Point(510, 128);
            this.cardStatus.Size = new Size(380, 210);
            this.cardStatus.BackColor = this.cardBackground;
            this.cardStatus.BorderColor = this.cardBorder;
            this.cardStatus.CornerRadius = 12;

            this.lblStatusHeader = CreateCardHeader("Verification Status");

            this.lblIdStatusCaption = CreateCaptionLabel("Identity Verification", 18, 60);
            this.lblIdStatusValue = new Label();
            this.lblIdStatusValue.Text = "Not Submitted";
            this.lblIdStatusValue.ForeColor = this.statusNotSubmittedColor;
            this.lblIdStatusValue.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblIdStatusValue.Location = new Point(230, 58);
            this.lblIdStatusValue.AutoSize = true;

            this.lblQualStatusCaption = CreateCaptionLabel("Qualification Verification", 18, 110);
            this.lblQualStatusValue = new Label();
            this.lblQualStatusValue.Text = "Not Submitted";
            this.lblQualStatusValue.ForeColor = this.statusNotSubmittedColor;
            this.lblQualStatusValue.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblQualStatusValue.Location = new Point(230, 108);
            this.lblQualStatusValue.AutoSize = true;

            this.lblStatusNote = new Label();
            this.lblStatusNote.Text = "Status changes to \"Verified\" or \"Rejected\" only after an\nadministrator reviews your request.";
            this.lblStatusNote.Font = new Font("Segoe UI", 8F, FontStyle.Italic);
            this.lblStatusNote.ForeColor = this.textSecondary;
            this.lblStatusNote.Location = new Point(18, 150);
            this.lblStatusNote.Size = new Size(344, 40);

            this.cardStatus.Controls.Add(this.lblStatusHeader);
            this.cardStatus.Controls.Add(this.lblIdStatusCaption);
            this.cardStatus.Controls.Add(this.lblIdStatusValue);
            this.cardStatus.Controls.Add(this.lblQualStatusCaption);
            this.cardStatus.Controls.Add(this.lblQualStatusValue);
            this.cardStatus.Controls.Add(this.lblStatusNote);

            
            this.cardDocuments = new RoundedCardPanel();
            this.cardDocuments.Location = new Point(30, 358);
            this.cardDocuments.Size = new Size(860, 150);
            this.cardDocuments.BackColor = this.cardBackground;
            this.cardDocuments.BorderColor = this.cardBorder;
            this.cardDocuments.CornerRadius = 12;

            this.lblDocumentsHeader = CreateCardHeader("Verification Documents");

            this.lblIdDocCaption = new Label();
            this.lblIdDocCaption.Text = "Identity Document";
            this.lblIdDocCaption.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblIdDocCaption.ForeColor = this.textPrimary;
            this.lblIdDocCaption.Location = new Point(18, 56);
            this.lblIdDocCaption.AutoSize = true;

            this.btnChooseIdDoc = CreateFileButton(18, 76);
            this.btnChooseIdDoc.Click += new System.EventHandler(this.btnChooseIdDoc_Click);

            this.lblIdDocFileName = new Label();
            this.lblIdDocFileName.Text = "No file selected";
            this.lblIdDocFileName.Font = new Font("Segoe UI", 8.5F, FontStyle.Italic);
            this.lblIdDocFileName.ForeColor = this.textSecondary;
            this.lblIdDocFileName.Location = new Point(158, 84);
            this.lblIdDocFileName.AutoSize = true;

            this.lblQualDocCaption = new Label();
            this.lblQualDocCaption.Text = "Qualification Certificate";
            this.lblQualDocCaption.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblQualDocCaption.ForeColor = this.textPrimary;
            this.lblQualDocCaption.Location = new Point(440, 56);
            this.lblQualDocCaption.AutoSize = true;

            this.btnChooseQualDoc = CreateFileButton(440, 76);
            this.btnChooseQualDoc.Click += new System.EventHandler(this.btnChooseQualDoc_Click);

            this.lblQualDocFileName = new Label();
            this.lblQualDocFileName.Text = "No file selected";
            this.lblQualDocFileName.Font = new Font("Segoe UI", 8.5F, FontStyle.Italic);
            this.lblQualDocFileName.ForeColor = this.textSecondary;
            this.lblQualDocFileName.Location = new Point(580, 84);
            this.lblQualDocFileName.AutoSize = true;

            this.cardDocuments.Controls.Add(this.lblDocumentsHeader);
            this.cardDocuments.Controls.Add(this.lblIdDocCaption);
            this.cardDocuments.Controls.Add(this.btnChooseIdDoc);
            this.cardDocuments.Controls.Add(this.lblIdDocFileName);
            this.cardDocuments.Controls.Add(this.lblQualDocCaption);
            this.cardDocuments.Controls.Add(this.btnChooseQualDoc);
            this.cardDocuments.Controls.Add(this.lblQualDocFileName);

            
            this.lblSubmitHint = new Label();
            this.lblSubmitHint.Text = "Your request will be reviewed by an administrator.";
            this.lblSubmitHint.ForeColor = this.textSecondary;
            this.lblSubmitHint.Font = new Font("Segoe UI", 8.5F);
            this.lblSubmitHint.Location = new Point(31, 533);
            this.lblSubmitHint.AutoSize = true;

            this.btnSubmit = new RoundedButton();
            this.btnSubmit.CornerRadius = 10;
            this.btnSubmit.Text = "Submit Verification Request";
            this.btnSubmit.Location = new Point(630, 524);
            this.btnSubmit.Size = new Size(260, 42);
            this.btnSubmit.BackColor = this.accentCyan;
            this.btnSubmit.ForeColor = this.appBackground;
            this.btnSubmit.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            this.btnSubmit.Cursor = Cursors.Hand;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            this.btnSubmit.MouseEnter += new System.EventHandler(this.btnSubmit_MouseEnter);
            this.btnSubmit.MouseLeave += new System.EventHandler(this.btnSubmit_MouseLeave);

            
            this.lblHistoryTitle = new Label();
            this.lblHistoryTitle.Text = "My Verification Requests";
            this.lblHistoryTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.lblHistoryTitle.ForeColor = this.textPrimary;
            this.lblHistoryTitle.Location = new Point(30, 590);
            this.lblHistoryTitle.AutoSize = true;

            this.dgvHistory = new DataGridView();
            this.dgvHistory.Location = new Point(30, 624);
            this.dgvHistory.Size = new Size(860, 140);
            this.dgvHistory.ReadOnly = true;
            this.dgvHistory.AllowUserToAddRows = false;
            this.dgvHistory.AllowUserToDeleteRows = false;
            this.dgvHistory.RowHeadersVisible = false;
            this.dgvHistory.BackgroundColor = this.cardBackground;
            this.dgvHistory.GridColor = this.cardBorder;
            this.dgvHistory.BorderStyle = BorderStyle.FixedSingle;
            this.dgvHistory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHistory.EnableHeadersVisualStyles = false;
            this.dgvHistory.ColumnHeadersDefaultCellStyle.BackColor = this.inputBackground;
            this.dgvHistory.ColumnHeadersDefaultCellStyle.ForeColor = this.textPrimary;
            this.dgvHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.dgvHistory.ColumnHeadersHeight = 34;
            this.dgvHistory.RowTemplate.Height = 30;
            this.dgvHistory.DefaultCellStyle.BackColor = this.cardBackground;
            this.dgvHistory.DefaultCellStyle.ForeColor = this.textPrimary;
            this.dgvHistory.DefaultCellStyle.SelectionBackColor = this.accentCyan;
            this.dgvHistory.DefaultCellStyle.SelectionForeColor = this.appBackground;
            this.dgvHistory.Columns.Add("RequestId", "Request ID");
            this.dgvHistory.Columns.Add("SubmittedDate", "Submitted");
            this.dgvHistory.Columns.Add("FullName", "Full Name");
            this.dgvHistory.Columns.Add("Qualification", "Qualification");
            this.dgvHistory.Columns.Add("Status", "Status");

            
            this.pnlContentScroll.Controls.Add(this.lblSectionTag);
            this.pnlContentScroll.Controls.Add(this.lblTitle);
            this.pnlContentScroll.Controls.Add(this.lblSubtitle);
            this.pnlContentScroll.Controls.Add(this.cardYourInfo);
            this.pnlContentScroll.Controls.Add(this.cardStatus);
            this.pnlContentScroll.Controls.Add(this.cardDocuments);
            this.pnlContentScroll.Controls.Add(this.lblSubmitHint);
            this.pnlContentScroll.Controls.Add(this.btnSubmit);
            this.pnlContentScroll.Controls.Add(this.lblHistoryTitle);
            this.pnlContentScroll.Controls.Add(this.dgvHistory);

            this.pnlContent.Controls.Add(this.pnlContentScroll);

           
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlSidebar);

            this.ResumeLayout(false);
        }

      
        private Button CreateNavButton(string text, int y)
        {
            var btn = new Button();
            btn.Text = "   " + text;
            btn.Location = new Point(0, y);
            btn.Size = new Size(220, 38);
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.TextAlign = ContentAlignment.MiddleLeft;
            btn.BackColor = this.sidebarBackground;
            btn.ForeColor = this.textPrimary;
            btn.Font = new Font("Segoe UI", 9.5F);
            btn.Cursor = Cursors.Hand;
            return btn;
        }

    
        private Label CreateCaptionLabel(string text, int x, int y)
        {
            var lbl = new Label();
            lbl.Text = text;
            lbl.ForeColor = this.textSecondary;
            lbl.Font = new Font("Segoe UI", 8.5F);
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
            return lbl;
        }

      
        private Label CreateCardHeader(string text)
        {
            var lbl = new Label();
            lbl.Text = text;
            lbl.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            lbl.ForeColor = this.textPrimary;
            lbl.Location = new Point(18, 14);
            lbl.AutoSize = true;
            return lbl;
        }

 
        private TextBox CreateInputBox(int x, int y, int width)
        {
            var txt = new TextBox();
            txt.Location = new Point(x, y);
            txt.Size = new Size(width, 24);
            txt.BackColor = this.inputBackground;
            txt.ForeColor = this.textPrimary;
            txt.BorderStyle = BorderStyle.FixedSingle;
            return txt;
        }

        private RoundedButton CreateFileButton(int x, int y)
        {
            var btn = new RoundedButton();
            btn.CornerRadius = 8;
            btn.Text = "Choose File...";
            btn.Location = new Point(x, y);
            btn.Size = new Size(130, 32);
            btn.BackColor = this.inputBackground;
            btn.ForeColor = this.textPrimary;
            btn.FlatAppearance.BorderColor = this.cardBorder;
            btn.Cursor = Cursors.Hand;
            btn.MouseEnter += new System.EventHandler(this.ChooseFileButton_MouseEnter);
            btn.MouseLeave += new System.EventHandler(this.ChooseFileButton_MouseLeave);
            return btn;
        }
    }
}
