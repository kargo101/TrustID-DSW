using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using TrustID.Verification.Models;

namespace TrustID.Verification.Forms
{
   
    public partial class MainForm : Form
    {
        
        private string selectedIdDocumentPath = string.Empty;
        private string selectedQualDocumentPath = string.Empty;

       
        private int requestCounter = 1000;

        public MainForm()
        {
            InitializeComponent();
            LoadAppIcon();
        }

        
        private void LoadAppIcon()
        {
            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                string resourceName = "TrustID.Verification.Resources.app_icon.ico";

                using (Stream iconStream = assembly.GetManifestResourceStream(resourceName))
                {
                    if (iconStream != null)
                    {
                        this.Icon = new Icon(iconStream);
                    }
                }
            }
            catch
            {
                
            }
        }

       

        private void btnChooseIdDoc_Click(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog())
            {
                dialog.Title = "Select Identity Document";
                dialog.Filter = "Documents (*.pdf;*.jpg;*.jpeg;*.png)|*.pdf;*.jpg;*.jpeg;*.png|All Files (*.*)|*.*";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    selectedIdDocumentPath = dialog.FileName;
                    lblIdDocFileName.Text = Path.GetFileName(selectedIdDocumentPath);
                    lblIdDocFileName.ForeColor = textPrimary;
                }
            }
        }

        private void btnChooseQualDoc_Click(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog())
            {
                dialog.Title = "Select Qualification Certificate";
                dialog.Filter = "Documents (*.pdf;*.jpg;*.jpeg;*.png)|*.pdf;*.jpg;*.jpeg;*.png|All Files (*.*)|*.*";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    selectedQualDocumentPath = dialog.FileName;
                    lblQualDocFileName.Text = Path.GetFileName(selectedQualDocumentPath);
                    lblQualDocFileName.ForeColor = textPrimary;
                }
            }
        }

        

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!ValidateSubmission())
            {
                return;
            }

            
            requestCounter++;
            var request = new VerificationRequest
            {
                RequestId = "VR-" + requestCounter,
                SubmittedDate = DateTime.Now,
                FullName = txtFullName.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                Qualification = txtQualification.Text.Trim(),
                IdentityDocumentPath = selectedIdDocumentPath,
                QualificationDocumentPath = selectedQualDocumentPath,
                Status = "Pending"
            };

            AddRequestToHistory(request);

            
            SetStatusLabel(lblIdStatusValue, "Pending");
            SetStatusLabel(lblQualStatusValue, "Pending");

            ResetSubmissionForm();

            MessageBox.Show(
                "Your verification request has been submitted and is now pending review.",
                "Request Submitted",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        
        private bool ValidateSubmission()
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                MessageBox.Show("Please enter your full name.", "Missing Information",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFullName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text) || !txtEmail.Text.Contains("@"))
            {
                MessageBox.Show("Please enter a valid email address.", "Missing Information",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmail.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtQualification.Text))
            {
                MessageBox.Show("Please enter your qualification.", "Missing Information",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtQualification.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(selectedIdDocumentPath))
            {
                MessageBox.Show("Please choose an identity document to upload.", "Missing Document",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(selectedQualDocumentPath))
            {
                MessageBox.Show("Please choose a qualification certificate to upload.", "Missing Document",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

      
        private void AddRequestToHistory(VerificationRequest request)
        {
            int rowIndex = dgvHistory.Rows.Add(
                request.RequestId,
                request.SubmittedDate.ToString("dd MMM yyyy"),
                request.FullName,
                request.Qualification,
                request.Status);

            dgvHistory.Rows[rowIndex].Cells["Status"].Style.ForeColor = statusPendingColor;
            dgvHistory.Rows[rowIndex].Cells["Status"].Style.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        }

       
        private void SetStatusLabel(Label label, string status)
        {
            label.Text = status;

            if (status == "Verified")
            {
                label.ForeColor = statusVerifiedColor;
            }
            else if (status == "Rejected")
            {
                label.ForeColor = statusRejectedColor;
            }
            else if (status == "Pending")
            {
                label.ForeColor = statusPendingColor;
            }
            else
            {
                label.ForeColor = statusNotSubmittedColor;
            }
        }

        
        private void ResetSubmissionForm()
        {
            txtFullName.Clear();
            txtEmail.Clear();
            txtQualification.Clear();

            selectedIdDocumentPath = string.Empty;
            selectedQualDocumentPath = string.Empty;

            lblIdDocFileName.Text = "No file selected";
            lblIdDocFileName.ForeColor = textSecondary;
            lblQualDocFileName.Text = "No file selected";
            lblQualDocFileName.ForeColor = textSecondary;
        }

        
        private void pnlAvatar_Paint(object sender, PaintEventArgs e)
        {
            using (var brush = new SolidBrush(accentCyan))
            {
                e.Graphics.FillEllipse(brush, 0, 0, pnlAvatar.Width - 1, pnlAvatar.Height - 1);
            }
        }

       
        private void ChooseFileButton_MouseEnter(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (btn != null)
            {
                btn.BackColor = Color.FromArgb(40, 52, 76);
            }
        }

        private void ChooseFileButton_MouseLeave(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (btn != null)
            {
                btn.BackColor = inputBackground;
            }
        }

        
        private void btnSubmit_MouseEnter(object sender, EventArgs e)
        {
            btnSubmit.BackColor = Color.FromArgb(20, 180, 205);
        }

        private void btnSubmit_MouseLeave(object sender, EventArgs e)
        {
            btnSubmit.BackColor = accentCyan;
        }
    }
}
