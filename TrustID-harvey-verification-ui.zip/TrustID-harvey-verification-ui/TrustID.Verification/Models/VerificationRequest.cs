using System;

namespace TrustID.Verification.Models
{
    
    public class VerificationRequest
    {
        public string RequestId { get; set; }
        public DateTime SubmittedDate { get; set; }

        
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Qualification { get; set; }

        public string IdentityDocumentPath { get; set; }
        public string QualificationDocumentPath { get; set; }

       
        public string Status { get; set; } = "Pending";
    }
}
