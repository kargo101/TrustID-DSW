using System;
using System.Windows.Forms;
using TrustID.Verification.Forms;

namespace TrustID.Verification
{
   
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            
            Application.Run(new MainForm());
        }
    }
}
