﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace UserSearch
{
    public partial class Form1 : Form
    {
        private UcUserSearch _searchControl;

        public Form1()
        {
            SetupForm();
            LoadData();
        }

        private void SetupForm()
        {
            this.Text = "User Management Dashboard";
            this.Size = new System.Drawing.Size(1050, 720);
            this.StartPosition = FormStartPosition.CenterScreen;

            _searchControl = new UcUserSearch
            {
                Dock = DockStyle.Fill
            };

            // Hook up the profile selection event
            _searchControl.ProfileSelected += SearchControl_ProfileSelected;
            this.Controls.Add(_searchControl);
        }

        private void LoadData()
        {
            var users = new List<UserRecord>
            {
                new UserRecord { Name = "Alice Vance", Role = "Software Engineer", TrustScore = 98, Location = "San Francisco, CA", Tags = new List<string>{ "C#", "WinForms" } },
                new UserRecord { Name = "Bob Smith", Role = "Product Designer", TrustScore = 85, Location = "New York, NY", Tags = new List<string>{ "UI/UX", "Figma" } },
                new UserRecord { Name = "Charlie Davis", Role = "DevOps Specialist", TrustScore = 92, Location = "Austin, TX", Tags = new List<string>{ "Azure", "Docker" } },
                new UserRecord { Name = "Diana Prince", Role = "Security Analyst", TrustScore = 99, Location = "Seattle, WA", Tags = new List<string>{ "Cybersecurity" } }
            };

            _searchControl.SetUsers(users);
        }

        private void SearchControl_ProfileSelected(object sender, UserRecord record)
        {
            // Launch the detailed profile modal
            using (var profileForm = new FormUserProfile(record))
            {
                profileForm.ShowDialog(this);
            }
        }
    }
}