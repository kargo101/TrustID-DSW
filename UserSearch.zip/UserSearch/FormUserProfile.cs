﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace UserSearch
{
    public class FormUserProfile : Form
    {
        private static readonly Color BgDark = Color.FromArgb(15, 20, 28);
        private static readonly Color CardBg = Color.FromArgb(22, 28, 38);
        private static readonly Color BorderCol = Color.FromArgb(40, 48, 60);
        private static readonly Color Accent = Color.FromArgb(45, 212, 191);
        private static readonly Color TextMain = Color.White;
        private static readonly Color TextMuted = Color.FromArgb(150, 160, 175);

        public FormUserProfile(UserRecord user)
        {
            InitializeComponent(user);
        }

        private void InitializeComponent(UserRecord user)
        {
            this.Text = $"{user.Name} - Detailed Profile";
            this.Size = new Size(480, 520);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = BgDark;

            var container = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(24)
            };
            this.Controls.Add(container);

            // Card Panel
            var card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = CardBg,
                Padding = new Padding(20)
            };
            card.Paint += (s, e) =>
            {
                using (var pen = new Pen(BorderCol, 1))
                {
                    e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
                }
            };
            container.Controls.Add(card);

            // Avatar Placeholder
            var avatar = new Panel
            {
                Size = new Size(64, 64),
                Location = new Point(20, 20),
                BackColor = Color.FromArgb(60, 65, 75)
            };

            // User Name
            var lblName = new Label
            {
                Text = user.Name,
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = TextMain,
                AutoSize = true,
                Location = new Point(96, 20)
            };

            // Role
            var lblRole = new Label
            {
                Text = user.Role,
                Font = new Font("Segoe UI", 10f),
                ForeColor = TextMuted,
                AutoSize = true,
                Location = new Point(96, 52)
            };

            // Divider Line
            var divider = new Panel
            {
                Location = new Point(20, 100),
                Size = new Size(card.Width - 40, 1),
                BackColor = BorderCol
            };

            // Details Section
            var lblDetailsHeader = new Label
            {
                Text = "ACCOUNT DETAILS",
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = TextMuted,
                AutoSize = true,
                Location = new Point(20, 115)
            };

            var lblLocation = new Label
            {
                Text = $"Location: {user.Location}",
                Font = new Font("Segoe UI", 10f),
                ForeColor = TextMain,
                AutoSize = true,
                Location = new Point(20, 145)
            };

            var lblScore = new Label
            {
                Text = $"Trust Score: {user.TrustScore} / 100",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Accent,
                AutoSize = true,
                Location = new Point(20, 175)
            };

            // Tags Section
            var lblTagsHeader = new Label
            {
                Text = "SKILLS & TAGS",
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = TextMuted,
                AutoSize = true,
                Location = new Point(20, 215)
            };

            var tagFlow = new FlowLayoutPanel
            {
                Location = new Point(20, 240),
                Size = new Size(card.Width - 40, 80),
                WrapContents = true
            };

            foreach (var tag in user.Tags)
            {
                var tagLbl = new Label
                {
                    Text = tag,
                    BackColor = Color.FromArgb(35, 42, 54),
                    ForeColor = TextMain,
                    AutoSize = true,
                    Padding = new Padding(8, 4, 8, 4),
                    Margin = new Padding(0, 0, 8, 8)
                };
                tagFlow.Controls.Add(tagLbl);
            }

            // Close Button
            var btnClose = new Button
            {
                Text = "Close",
                BackColor = Accent,
                ForeColor = Color.FromArgb(10, 15, 20),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(100, 36),
                Location = new Point(card.Width - 120, card.Height - 56),
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => this.Close();

            card.Controls.Add(avatar);
            card.Controls.Add(lblName);
            card.Controls.Add(lblRole);
            card.Controls.Add(divider);
            card.Controls.Add(lblDetailsHeader);
            card.Controls.Add(lblLocation);
            card.Controls.Add(lblScore);
            card.Controls.Add(lblTagsHeader);
            card.Controls.Add(tagFlow);
            card.Controls.Add(btnClose);
        }
    }
}