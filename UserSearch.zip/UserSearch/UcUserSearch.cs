﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace UserSearch
{
    // 1. Data Model
    public class UserRecord
    {
        public string Name { get; set; }
        public string Role { get; set; }
        public int TrustScore { get; set; }
        public string Location { get; set; }
        public List<string> Tags { get; set; } = new List<string>();
    }

    // 2. Custom UserControl
    public class UcUserSearch : UserControl
    {
        // Custom Event for Parent Form Communication
        public event EventHandler<UserRecord> ProfileSelected;

        // Constants & Fields
        private const int PageSize = 3;
        private int _currentPage = 1;
        private List<UserRecord> _allUsers = new List<UserRecord>();
        private List<UserRecord> _filteredUsers = new List<UserRecord>();

        // Theme Palette
        private static readonly Color BgDark = Color.FromArgb(15, 20, 28);
        private static readonly Color CardBg = Color.FromArgb(22, 28, 38);
        private static readonly Color BorderCol = Color.FromArgb(40, 48, 60);
        private static readonly Color Accent = Color.FromArgb(45, 212, 191);
        private static readonly Color TextMain = Color.White;
        private static readonly Color TextMuted = Color.FromArgb(150, 160, 175);

        // UI Controls
        private TextBox _txtSearch;
        private ComboBox _cmbSort;
        private FlowLayoutPanel _pnlResults;
        private Panel _pnlPagination;
        private Label _lblResultsCount;

        public UcUserSearch()
        {
            InitializeControl();
        }

        private void InitializeControl()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = BgDark;

            var root = new TableLayoutPanel
            {
                RowCount = 3,
                ColumnCount = 1,
                Dock = DockStyle.Fill,
                Padding = new Padding(16)
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 50f));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 50f));

            // Top Search Bar Panel
            var topPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };

            _txtSearch = new TextBox { Width = 200, Font = new Font("Segoe UI", 10f) };
            _txtSearch.TextChanged += (s, e) => { _currentPage = 1; RunSearch(); };

            _cmbSort = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 150 };
            _cmbSort.Items.AddRange(new string[] { "Name (A-Z)", "Trust Score (High-Low)" });
            _cmbSort.SelectedIndex = 0;
            _cmbSort.SelectedIndexChanged += (s, e) => RunSearch();

            _lblResultsCount = new Label { ForeColor = TextMuted, AutoSize = true, Margin = new Padding(10, 5, 0, 0) };

            topPanel.Controls.Add(_txtSearch);
            topPanel.Controls.Add(_cmbSort);
            topPanel.Controls.Add(_lblResultsCount);

            // Center Grid Area
            _pnlResults = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true };

            // Bottom Pagination Panel
            _pnlPagination = new Panel { Dock = DockStyle.Fill };

            root.Controls.Add(topPanel, 0, 0);
            root.Controls.Add(_pnlResults, 0, 1);
            root.Controls.Add(_pnlPagination, 0, 2);

            this.Controls.Add(root);
        }

        public void SetUsers(List<UserRecord> users)
        {
            _allUsers = users ?? new List<UserRecord>();
            _currentPage = 1;
            RunSearch();
        }

        private void RunSearch()
        {
            string query = _txtSearch?.Text?.ToLower() ?? "";

            _filteredUsers = _allUsers
                .Where(u => string.IsNullOrEmpty(query) ||
                            u.Name.ToLower().Contains(query) ||
                            u.Role.ToLower().Contains(query))
                .ToList();

            if (_cmbSort?.SelectedIndex == 1)
                _filteredUsers = _filteredUsers.OrderByDescending(u => u.TrustScore).ToList();
            else
                _filteredUsers = _filteredUsers.OrderBy(u => u.Name).ToList();

            if (_lblResultsCount != null)
                _lblResultsCount.Text = $"{_filteredUsers.Count} Users Found";

            RenderPage();
            RenderPagination();
        }

        private void RenderPage()
        {
            _pnlResults.Controls.Clear();

            var pagedItems = _filteredUsers
                .Skip((_currentPage - 1) * PageSize)
                .Take(PageSize);

            foreach (var user in pagedItems)
            {
                _pnlResults.Controls.Add(BuildCard(user));
            }
        }

        private Panel BuildCard(UserRecord user)
        {
            var card = new Panel
            {
                Size = new Size(280, 180),
                BackColor = CardBg,
                Margin = new Padding(8)
            };

            var lblName = new Label
            {
                Text = user.Name,
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = TextMain,
                Location = new Point(12, 12),
                AutoSize = true
            };

            var lblRole = new Label
            {
                Text = user.Role,
                Font = new Font("Segoe UI", 9f),
                ForeColor = TextMuted,
                Location = new Point(12, 38),
                AutoSize = true
            };

            var btnView = new Button
            {
                Text = "View Profile",
                Tag = user,
                Location = new Point(12, 130),
                Size = new Size(100, 30),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Accent,
                Cursor = Cursors.Hand
            };
            btnView.Click += btnView_Click;

            card.Controls.Add(lblName);
            card.Controls.Add(lblRole);
            card.Controls.Add(btnView);

            return card;
        }

        private void RenderPagination()
        {
            _pnlPagination.Controls.Clear();

            int totalPages = (int)Math.Ceiling((double)_filteredUsers.Count / PageSize);
            if (totalPages <= 1) return;

            var btnPrev = new Button
            {
                Text = "<",
                Size = new Size(36, 32),
                Location = new Point(0, 8),
                Enabled = _currentPage > 1
            };
            btnPrev.Click += btnPrev_Click;

            var btnNext = new Button
            {
                Text = ">",
                Size = new Size(36, 32),
                Location = new Point(44, 8),
                Enabled = _currentPage < totalPages
            };
            btnNext.Click += btnNext_Click;

            var lblPage = new Label
            {
                Text = $"Page {_currentPage} of {totalPages}",
                ForeColor = TextMuted,
                Location = new Point(90, 14),
                AutoSize = true
            };

            _pnlPagination.Controls.Add(btnPrev);
            _pnlPagination.Controls.Add(btnNext);
            _pnlPagination.Controls.Add(lblPage);
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            if (sender is Button btn && btn.Tag is UserRecord record)
            {
                ProfileSelected?.Invoke(this, record);
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (_currentPage > 1)
            {
                _currentPage--;
                RunSearch();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            int totalPages = (int)Math.Ceiling((double)_filteredUsers.Count / PageSize);
            if (_currentPage < totalPages)
            {
                _currentPage++;
                RunSearch();
            }
        }
    }
}


